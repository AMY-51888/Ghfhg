<template>
  <div class="home">
    <header class="header">
      <div class="container">
        <h1 class="logo">TikTok资源资讯聚合</h1>
        <nav class="nav">
          <router-link to="/">首页</router-link>
          <router-link to="/category/1">运营教程</router-link>
          <router-link to="/category/2">小店电商</router-link>
          <router-link to="/category/3">广告投放</router-link>
          <router-link to="/category/4">工具资源</router-link>
          <router-link to="/category/5">最新资讯</router-link>
        </nav>
        <div class="search-box">
          <el-input v-model="searchQuery" placeholder="搜索资讯..." @keyup.enter="handleSearch" />
          <el-button @click="handleSearch">搜索</el-button>
        </div>
      </div>
    </header>
    
    <main class="main container">
      <section class="section">
        <h2 class="section-title">最新资讯</h2>
        <div class="article-grid">
          <div v-for="article in latestArticles" :key="article.id" class="article-card">
            <router-link :to="`/article/${article.id}`">
              <div class="article-cover" v-if="article.cover">
                <img :src="article.cover" :alt="article.title" />
              </div>
              <div class="article-info">
                <h3 class="article-title">{{ article.title }}</h3>
                <p class="article-summary">{{ article.summary }}</p>
                <span class="article-time">{{ formatTime(article.publish_time) }}</span>
              </div>
            </router-link>
          </div>
        </div>
      </section>
      
      <section class="section">
        <h2 class="section-title">热门教程</h2>
        <div class="article-grid">
          <div v-for="article in hotArticles" :key="article.id" class="article-card">
            <router-link :to="`/article/${article.id}`">
              <div class="article-cover" v-if="article.cover">
                <img :src="article.cover" :alt="article.title" />
              </div>
              <div class="article-info">
                <h3 class="article-title">{{ article.title }}</h3>
                <p class="article-summary">{{ article.summary }}</p>
                <span class="article-time">{{ formatTime(article.publish_time) }}</span>
              </div>
            </router-link>
          </div>
        </div>
      </section>
      
      <section class="section">
        <h2 class="section-title">分类浏览</h2>
        <div class="category-list">
          <router-link 
            v-for="cat in categories" 
            :key="cat.id" 
            :to="`/category/${cat.id}`"
            class="category-item"
          >
            <span class="category-name">{{ cat.name }}</span>
            <span class="category-count">{{ cat.count }} 篇</span>
          </router-link>
        </div>
      </section>
    </main>
    
    <footer class="footer">
      <p>TikTok资源资讯聚合平台 - 专业的TikTok运营资源聚合站</p>
    </footer>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import { useRouter } from 'vue-router'
import { homeApi } from '@/api/articles'

const router = useRouter()
const searchQuery = ref('')
const latestArticles = ref([])
const hotArticles = ref([])
const categories = ref([])

const loadHomeData = async () => {
  try {
    const res = await homeApi.data()
    if (res.code === 0) {
      latestArticles.value = res.data.latest_articles || []
      hotArticles.value = res.data.hot_articles || []
      categories.value = res.data.categories || []
    }
  } catch (error) {
    console.error('Failed to load home data:', error)
  }
}

const handleSearch = () => {
  if (searchQuery.value.trim()) {
    router.push({ name: 'Search', query: { q: searchQuery.value } })
  }
}

const formatTime = (time) => {
  if (!time) return ''
  return new Date(time).toLocaleDateString('zh-CN')
}

onMounted(() => {
  loadHomeData()
})
</script>

<style scoped>
.home {
  min-height: 100vh;
  background: #f5f5f5;
}

.container {
  max-width: 1200px;
  margin: 0 auto;
  padding: 0 20px;
}

.header {
  background: #fff;
  box-shadow: 0 2px 8px rgba(0,0,0,0.1);
  padding: 20px 0;
}

.header .container {
  display: flex;
  align-items: center;
  gap: 40px;
}

.logo {
  font-size: 24px;
  color: #fe2c55;
  margin: 0;
}

.nav {
  display: flex;
  gap: 24px;
}

.nav a {
  color: #333;
  text-decoration: none;
  font-size: 16px;
}

.nav a:hover {
  color: #fe2c55;
}

.search-box {
  display: flex;
  gap: 8px;
  margin-left: auto;
}

.main {
  padding: 40px 20px;
}

.section {
  margin-bottom: 40px;
}

.section-title {
  font-size: 24px;
  color: #333;
  margin-bottom: 20px;
  padding-bottom: 10px;
  border-bottom: 2px solid #fe2c55;
}

.article-grid {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(280px, 1fr));
  gap: 20px;
}

.article-card {
  background: #fff;
  border-radius: 8px;
  overflow: hidden;
  box-shadow: 0 2px 8px rgba(0,0,0,0.08);
  transition: transform 0.2s;
}

.article-card:hover {
  transform: translateY(-4px);
}

.article-card a {
  text-decoration: none;
  color: inherit;
}

.article-cover img {
  width: 100%;
  height: 160px;
  object-fit: cover;
}

.article-info {
  padding: 16px;
}

.article-title {
  font-size: 16px;
  margin: 0 0 8px;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}

.article-summary {
  font-size: 14px;
  color: #666;
  margin: 0 0 12px;
  overflow: hidden;
  text-overflow: ellipsis;
  display: -webkit-box;
  -webkit-line-clamp: 2;
  -webkit-box-orient: vertical;
}

.article-time {
  font-size: 12px;
  color: #999;
}

.category-list {
  display: flex;
  flex-wrap: wrap;
  gap: 12px;
}

.category-item {
  display: flex;
  align-items: center;
  gap: 8px;
  padding: 12px 24px;
  background: #fff;
  border-radius: 4px;
  text-decoration: none;
  transition: background 0.2s;
}

.category-item:hover {
  background: #fe2c55;
  color: #fff;
}

.category-name {
  font-size: 16px;
}

.category-count {
  font-size: 12px;
  color: #999;
}

.category-item:hover .category-count {
  color: rgba(255,255,255,0.8);
}

.footer {
  background: #333;
  color: #fff;
  text-align: center;
  padding: 20px;
  margin-top: 40px;
}
</style>
