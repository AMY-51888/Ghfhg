<template>
  <div class="search-page">
    <header class="header">
      <div class="container">
        <router-link to="/" class="back-home">返回首页</router-link>
        <h1>搜索结果</h1>
      </div>
    </header>
    
    <main class="main container">
      <div class="search-info">
        <span>关键词: {{ keyword }}</span>
        <span>找到 {{ total }} 个结果</span>
      </div>
      
      <div class="article-list" v-loading="loading">
        <div v-for="article in articles" :key="article.id" class="article-item">
          <router-link :to="`/article/${article.id}`" class="article-link">
            <h2 class="article-title">{{ article.title }}</h2>
            <p class="article-summary">{{ article.summary }}</p>
            <div class="article-meta">
              <span>{{ formatTime(article.publish_time) }}</span>
            </div>
          </router-link>
        </div>
        
        <el-empty v-if="!loading && articles.length === 0" description="未找到相关文章" />
      </div>
      
      <div class="pagination" v-if="total > 0">
        <el-pagination
          v-model:current-page="page"
          :page-size="pageSize"
          :total="total"
          layout="prev, pager, next"
          @current-change="loadSearch"
        />
      </div>
    </main>
  </div>
</template>

<script setup>
import { ref, onMounted, computed } from 'vue'
import { useRoute } from 'vue-router'
import { articleApi } from '@/api/articles'

const route = useRoute()
const loading = ref(false)
const articles = ref([])
const page = ref(1)
const pageSize = ref(20)
const total = ref(0)

const keyword = computed(() => route.query.q || '')

const loadSearch = async () => {
  if (!keyword.value) return
  
  loading.value = true
  try {
    const res = await articleApi.search({
      q: keyword.value,
      page: page.value,
      page_size: pageSize.value
    })
    if (res.code === 0) {
      articles.value = res.data.items || []
      total.value = res.data.total || 0
    }
  } catch (error) {
    console.error('Failed to search:', error)
  } finally {
    loading.value = false
  }
}

const formatTime = (time) => {
  if (!time) return ''
  return new Date(time).toLocaleDateString('zh-CN')
}

onMounted(() => {
  loadSearch()
})
</script>

<style scoped>
.search-page {
  min-height: 100vh;
  background: #f5f5f5;
}

.container {
  max-width: 1200px;
  margin: 0 auto;
  padding: 0 20px;
}

.header {
  background: #fff;
  padding: 20px 0;
  box-shadow: 0 2px 8px rgba(0,0,0,0.1);
}

.header .container {
  display: flex;
  align-items: center;
  gap: 20px;
}

.back-home {
  color: #fe2c55;
  text-decoration: none;
}

.header h1 {
  margin: 0;
  font-size: 24px;
}

.main {
  padding: 40px 20px;
}

.search-info {
  display: flex;
  justify-content: space-between;
  margin-bottom: 20px;
  color: #666;
}

.article-list {
  display: flex;
  flex-direction: column;
  gap: 16px;
}

.article-item {
  background: #fff;
  border-radius: 8px;
  overflow: hidden;
  box-shadow: 0 2px 8px rgba(0,0,0,0.08);
}

.article-link {
  display: block;
  padding: 20px;
  text-decoration: none;
  color: inherit;
}

.article-title {
  margin: 0 0 12px;
  font-size: 18px;
  color: #333;
}

.article-summary {
  color: #666;
  font-size: 14px;
  margin: 0 0 12px;
}

.article-meta {
  font-size: 12px;
  color: #999;
}

.pagination {
  display: flex;
  justify-content: center;
  margin-top: 40px;
}
</style>
