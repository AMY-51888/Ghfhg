<template>
  <div class="article-detail">
    <header class="header">
      <div class="container">
        <router-link to="/" class="back-home">返回首页</router-link>
      </div>
    </header>
    
    <main class="main container" v-loading="loading">
      <article class="article" v-if="article">
        <header class="article-header">
          <h1 class="article-title">{{ article.title }}</h1>
          <div class="article-meta">
            <span v-if="article.author">{{ article.author }}</span>
            <span>{{ formatTime(article.publish_time) }}</span>
            <span>{{ article.category_name }}</span>
          </div>
        </header>
        
        <div class="article-cover" v-if="article.cover">
          <img :src="article.cover" :alt="article.title" />
        </div>
        
        <div class="article-body" v-html="article.content"></div>
        
        <footer class="article-footer">
          <div class="article-tags" v-if="article.tags">
            <span class="tag-label">标签：</span>
            <el-tag v-for="tag in article.tags.split(',')" :key="tag" size="small">
              {{ tag }}
            </el-tag>
          </div>
          <div class="article-source" v-if="article.source_url">
            <span>来源：</span>
            <a :href="article.source_url" target="_blank">{{ article.source_url }}</a>
          </div>
        </footer>
      </article>
      
      <el-empty v-else description="文章不存在" />
    </main>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import { useRoute } from 'vue-router'
import { articleApi } from '@/api/articles'

const route = useRoute()
const loading = ref(false)
const article = ref(null)

const loadArticle = async () => {
  loading.value = true
  try {
    const res = await articleApi.detail(route.params.id)
    if (res.code === 0) {
      article.value = res.data
    }
  } catch (error) {
    console.error('Failed to load article:', error)
  } finally {
    loading.value = false
  }
}

const formatTime = (time) => {
  if (!time) return ''
  return new Date(time).toLocaleString('zh-CN')
}

onMounted(() => {
  loadArticle()
})
</script>

<style scoped>
.article-detail {
  min-height: 100vh;
  background: #f5f5f5;
}

.container {
  max-width: 900px;
  margin: 0 auto;
  padding: 0 20px;
}

.header {
  background: #fff;
  padding: 20px 0;
  box-shadow: 0 2px 8px rgba(0,0,0,0.1);
}

.back-home {
  color: #fe2c55;
  text-decoration: none;
}

.main {
  padding: 40px 20px;
}

.article {
  background: #fff;
  border-radius: 8px;
  padding: 40px;
  box-shadow: 0 2px 8px rgba(0,0,0,0.08);
}

.article-header {
  margin-bottom: 30px;
  padding-bottom: 20px;
  border-bottom: 1px solid #eee;
}

.article-title {
  font-size: 28px;
  margin: 0 0 16px;
  line-height: 1.4;
}

.article-meta {
  display: flex;
  gap: 20px;
  color: #999;
  font-size: 14px;
}

.article-cover {
  margin-bottom: 30px;
}

.article-cover img {
  width: 100%;
  border-radius: 8px;
}

.article-body {
  font-size: 16px;
  line-height: 1.8;
  color: #333;
}

.article-body :deep(p) {
  margin-bottom: 16px;
}

.article-footer {
  margin-top: 40px;
  padding-top: 20px;
  border-top: 1px solid #eee;
}

.article-tags {
  display: flex;
  align-items: center;
  gap: 8px;
  margin-bottom: 16px;
}

.tag-label {
  color: #666;
}

.article-source {
  color: #666;
  font-size: 14px;
}

.article-source a {
  color: #fe2c55;
}
</style>
