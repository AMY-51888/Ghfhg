<template>
  <div class="category-page">
    <header class="header">
      <div class="container">
        <router-link to="/" class="back-home">返回首页</router-link>
        <h1>{{ categoryName }}</h1>
      </div>
    </header>
    
    <main class="main container">
      <div class="article-list" v-loading="loading">
        <div v-for="article in articles" :key="article.id" class="article-item">
          <router-link :to="`/article/${article.id}`" class="article-link">
            <div class="article-cover" v-if="article.cover">
              <img :src="article.cover" :alt="article.title" />
            </div>
            <div class="article-content">
              <h2 class="article-title">{{ article.title }}</h2>
              <p class="article-summary">{{ article.summary }}</p>
              <div class="article-meta">
                <span v-if="article.author">{{ article.author }}</span>
                <span>{{ formatTime(article.publish_time) }}</span>
              </div>
            </div>
          </router-link>
        </div>
        
        <el-empty v-if="!loading && articles.length === 0" description="暂无文章" />
      </div>
      
      <div class="pagination" v-if="total > 0">
        <el-pagination
          v-model:current-page="page"
          :page-size="pageSize"
          :total="total"
          layout="prev, pager, next"
          @current-change="loadArticles"
        />
      </div>
    </main>
  </div>
</template>

<script setup>
import { ref, onMounted, computed } from 'vue'
import { useRoute } from 'vue-router'
import { articleApi, categoryApi } from '@/api/articles'

const route = useRoute()
const loading = ref(false)
const articles = ref([])
const page = ref(1)
const pageSize = ref(20)
const total = ref(0)
const categories = ref([])

const categoryName = computed(() => {
  const cat = categories.value.find(c => c.id === Number(route.params.id))
  return cat ? cat.name : '文章列表'
})

const loadCategories = async () => {
  try {
    const res = await categoryApi.list()
    if (res.code === 0) {
      categories.value = res.data || []
    }
  } catch (error) {
    console.error('Failed to load categories:', error)
  }
}

const loadArticles = async () => {
  loading.value = true
  try {
    const res = await articleApi.category(route.params.id, {
      page: page.value,
      page_size: pageSize.value
    })
    if (res.code === 0) {
      articles.value = res.data.items || []
      total.value = res.data.total || 0
    }
  } catch (error) {
    console.error('Failed to load articles:', error)
  } finally {
    loading.value = false
  }
}

const formatTime = (time) => {
  if (!time) return ''
  return new Date(time).toLocaleDateString('zh-CN')
}

onMounted(() => {
  loadCategories()
  loadArticles()
})
</script>

<style scoped>
.category-page {
  min-height: 100vh;
  background: #f5f5f5;
}

.container {
  max-width: 1200px;
  margin: 0 auto;
  padding: 0 20px;
}

.header {
  background: #fff;
  padding: 20px 0;
  box-shadow: 0 2px 8px rgba(0,0,0,0.1);
}

.header .container {
  display: flex;
  align-items: center;
  gap: 20px;
}

.back-home {
  color: #fe2c55;
  text-decoration: none;
}

.header h1 {
  margin: 0;
  font-size: 24px;
}

.main {
  padding: 40px 20px;
}

.article-list {
  display: flex;
  flex-direction: column;
  gap: 16px;
}

.article-item {
  background: #fff;
  border-radius: 8px;
  overflow: hidden;
  box-shadow: 0 2px 8px rgba(0,0,0,0.08);
}

.article-link {
  display: flex;
  gap: 20px;
  padding: 20px;
  text-decoration: none;
  color: inherit;
}

.article-cover {
  width: 200px;
  height: 120px;
  flex-shrink: 0;
}

.article-cover img {
  width: 100%;
  height: 100%;
  object-fit: cover;
}

.article-content {
  flex: 1;
  display: flex;
  flex-direction: column;
}

.article-title {
  margin: 0 0 12px;
  font-size: 18px;
}

.article-summary {
  flex: 1;
  color: #666;
  font-size: 14px;
  margin: 0 0 12px;
}

.article-meta {
  display: flex;
  gap: 16px;
  font-size: 12px;
  color: #999;
}

.pagination {
  display: flex;
  justify-content: center;
  margin-top: 40px;
}
</style>
