<template>
  <div class="crawl-manage">
    <header class="header">
      <h1>采集任务管理</h1>
      <div class="actions">
        <el-button type="primary" @click="handleStartAll">启动全部</el-button>
        <el-button @click="loadTasks">刷新</el-button>
      </div>
    </header>
    
    <div class="content">
      <el-table :data="tasks" v-loading="loading">
        <el-table-column prop="id" label="ID" width="80" />
        <el-table-column prop="keyword" label="关键词" />
        <el-table-column prop="source" label="来源" width="120" />
        <el-table-column prop="status" label="状态" width="100">
          <template #default="{ row }">
            <el-tag :type="row.status === 'running' ? 'success' : 'info'">
              {{ row.status === 'running' ? '运行中' : '空闲' }}
            </el-tag>
          </template>
        </el-table-column>
        <el-table-column prop="last_crawl_time" label="最后采集时间" width="180" />
        <el-table-column label="操作" width="150">
          <template #default="{ row }">
            <el-button 
              v-if="row.status !== 'running'" 
              type="primary" 
              size="small" 
              @click="handleStart(row)"
            >
              启动
            </el-button>
            <el-button 
              v-else 
              type="danger" 
              size="small" 
              @click="handleStop(row)"
            >
              停止
            </el-button>
          </template>
        </el-table-column>
      </el-table>
      
      <el-card class="mt-20">
        <template #header>
          <span>采集日志</span>
        </template>
        <el-table :data="logs" style="width: 100%">
          <el-table-column prop="id" label="ID" width="80" />
          <el-table-column prop="task_id" label="任务ID" width="100" />
          <el-table-column prop="count" label="抓取数" width="100" />
          <el-table-column prop="duplicate_count" label="重复数" width="100" />
          <el-table-column prop="status" label="状态" width="100" />
          <el-table-column prop="msg" label="信息" show-overflow-tooltip />
          <el-table-column prop="create_time" label="时间" width="180" />
        </el-table>
      </el-card>
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import { ElMessage } from 'element-plus'
import { adminApi } from '@/api/admin'

const loading = ref(false)
const tasks = ref([])
const logs = ref([])

const loadTasks = async () => {
  loading.value = true
  try {
    const res = await adminApi.crawl.tasks()
    if (res.code === 0) {
      tasks.value = res.data || []
    }
    
    const logRes = await adminApi.crawl.logs({ page_size: 10 })
    if (logRes.code === 0) {
      logs.value = logRes.data.items || []
    }
  } catch (error) {
    console.error('Failed to load tasks:', error)
  } finally {
    loading.value = false
  }
}

const handleStart = async (task) => {
  try {
    await adminApi.crawl.start({ task_id: task.id })
    ElMessage.success('任务已启动')
    loadTasks()
  } catch (error) {
    console.error('Failed to start task:', error)
  }
}

const handleStartAll = async () => {
  try {
    await adminApi.crawl.start({ all: true })
    ElMessage.success('全部任务已启动')
    loadTasks()
  } catch (error) {
    console.error('Failed to start all tasks:', error)
  }
}

const handleStop = async (task) => {
  try {
    await adminApi.crawl.stop({ task_id: task.id })
    ElMessage.success('任务已停止')
    loadTasks()
  } catch (error) {
    console.error('Failed to stop task:', error)
  }
}

onMounted(() => {
  loadTasks()
})
</script>

<style scoped>
.crawl-manage {
  padding: 20px;
}

.header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 20px;
}

.header h1 {
  margin: 0;
  font-size: 24px;
}

.mt-20 {
  margin-top: 20px;
}
</style>
