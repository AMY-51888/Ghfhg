<template>
  <div class="settings">
    <header class="header">
      <h1>网站设置</h1>
      <el-button type="primary" @click="handleSave">保存设置</el-button>
    </header>
    
    <div class="content">
      <el-form :model="form" label-width="120px">
        <el-form-item label="网站名称">
          <el-input v-model="form.site_name" />
        </el-form-item>
        <el-form-item label="网站URL">
          <el-input v-model="form.site_url" />
        </el-form-item>
        <el-form-item label="SEO标题">
          <el-input v-model="form.seo_title" />
        </el-form-item>
        <el-form-item label="SEO关键词">
          <el-input v-model="form.seo_keywords" type="textarea" rows="2" />
        </el-form-item>
        <el-form-item label="SEO描述">
          <el-input v-model="form.seo_description" type="textarea" rows="3" />
        </el-form-item>
        <el-form-item label="网站Logo">
          <el-input v-model="form.site_logo" />
        </el-form-item>
      </el-form>
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import { ElMessage } from 'element-plus'
import { adminApi } from '@/api/admin'

const form = ref({
  site_name: '',
  site_url: '',
  seo_title: '',
  seo_keywords: '',
  seo_description: '',
  site_logo: ''
})

const loadSettings = async () => {
  try {
    const res = await adminApi.settings.get()
    if (res.code === 0) {
      form.value = { ...res.data }
    }
  } catch (error) {
    console.error('Failed to load settings:', error)
  }
}

const handleSave = async () => {
  try {
    await adminApi.settings.update(form.value)
    ElMessage.success('保存成功')
  } catch (error) {
    console.error('Failed to save settings:', error)
  }
}

onMounted(() => {
  loadSettings()
})
</script>

<style scoped>
.settings {
  padding: 20px;
}

.header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 20px;
}

.header h1 {
  margin: 0;
  font-size: 24px;
}

.content {
  background: #fff;
  padding: 20px;
  border-radius: 8px;
}
</style>
