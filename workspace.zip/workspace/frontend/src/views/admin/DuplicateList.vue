<template>
  <div class="duplicate-list">
    <header class="header">
      <h1>去重内容管理</h1>
    </header>
    
    <div class="content">
      <el-table :data="duplicates" v-loading="loading">
        <el-table-column prop="id" label="ID" width="80" />
        <el-table-column prop="title" label="标题" show-overflow-tooltip />
        <el-table-column prop="sim_hash" label="SimHash" width="120" show-overflow-tooltip />
        <el-table-column label="相似文章" width="200">
          <template #default="{ row }">
            <span v-if="row.duplicate_with">{{ row.duplicate_with.title }}</span>
            <span v-else>-</span>
          </template>
        </el-table-column>
        <el-table-column prop="create_time" label="发现时间" width="180" />
        <el-table-column label="操作" width="150" fixed="right">
          <template #default="{ row }">
            <el-button link type="primary" @click="handleKeep(row)">保留</el-button>
            <el-button link type="danger" @click="handleDelete(row)">删除</el-button>
          </template>
        </el-table-column>
      </el-table>
      
      <div class="pagination">
        <el-pagination
          v-model:current-page="page"
          :page-size="pageSize"
          :total="total"
          layout="total, prev, pager, next"
          @current-change="loadDuplicates"
        />
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import { ElMessage } from 'element-plus'
import { adminApi } from '@/api/admin'

const loading = ref(false)
const duplicates = ref([])
const page = ref(1)
const pageSize = ref(20)
const total = ref(0)

const loadDuplicates = async () => {
  loading.value = true
  try {
    const res = await adminApi.duplicates.list({
      page: page.value,
      page_size: pageSize.value
    })
    if (res.code === 0) {
      duplicates.value = res.data.items || []
      total.value = res.data.total || 0
    }
  } catch (error) {
    console.error('Failed to load duplicates:', error)
  } finally {
    loading.value = false
  }
}

const handleKeep = async (row) => {
  try {
    await adminApi.duplicates.handle({ id: row.id, action: 'keep' })
    ElMessage.success('已保留')
    loadDuplicates()
  } catch (error) {
    console.error('Failed to keep:', error)
  }
}

const handleDelete = async (row) => {
  try {
    await adminApi.duplicates.handle({ id: row.id, action: 'delete' })
    ElMessage.success('已删除')
    loadDuplicates()
  } catch (error) {
    console.error('Failed to delete:', error)
  }
}

onMounted(() => {
  loadDuplicates()
})
</script>

<style scoped>
.duplicate-list {
  padding: 20px;
}

.header {
  margin-bottom: 20px;
}

.header h1 {
  margin: 0;
  font-size: 24px;
}

.pagination {
  margin-top: 20px;
  display: flex;
  justify-content: flex-end;
}
</style>
