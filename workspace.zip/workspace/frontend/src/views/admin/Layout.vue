<template>
  <div class="admin-layout">
    <aside class="sidebar" v-if="isLoggedIn">
      <div class="logo">管理后台</div>
      <nav class="menu">
        <router-link to="/admin" exact>Dashboard</router-link>
        <router-link to="/admin/articles">文章管理</router-link>
        <router-link to="/admin/crawl">采集管理</router-link>
        <router-link to="/admin/duplicates">去重管理</router-link>
        <router-link to="/admin/categories">分类管理</router-link>
        <router-link to="/admin/keywords">关键词管理</router-link>
        <router-link to="/admin/settings">网站设置</router-link>
      </nav>
    </aside>
    
    <main class="main-content">
      <router-view />
    </main>
  </div>
</template>

<script setup>
import { computed } from 'vue'
import { useRoute } from 'vue-router'

const route = useRoute()
const isLoggedIn = computed(() => route.path !== '/admin/login')
</script>

<style scoped>
.admin-layout {
  display: flex;
  min-height: 100vh;
}

.sidebar {
  width: 240px;
  background: #304156;
  color: #fff;
  flex-shrink: 0;
}

.logo {
  padding: 20px;
  font-size: 20px;
  font-weight: bold;
  text-align: center;
  border-bottom: 1px solid #3d4d5c;
}

.menu {
  padding: 10px 0;
}

.menu a {
  display: block;
  padding: 14px 20px;
  color: #bfcbd9;
  text-decoration: none;
  transition: background 0.3s;
}

.menu a:hover,
.menu a.router-link-active {
  background: #263445;
  color: #fff;
}

.main-content {
  flex: 1;
  background: #f0f2f5;
}
</style>
