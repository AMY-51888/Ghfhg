<template>
  <div class="article-list">
    <header class="header">
      <h1>文章管理</h1>
      <div class="actions">
        <el-select v-model="filterStatus" placeholder="筛选状态" clearable @change="loadArticles">
          <el-option label="全部" :value="null" />
          <el-option label="待审核" :value="0" />
          <el-option label="已发布" :value="1" />
          <el-option label="垃圾内容" :value="2" />
        </el-select>
        <el-button type="danger" @click="handleBatchDelete">批量删除</el-button>
      </div>
    </header>
    
    <div class="content">
      <el-table :data="articles" @selection-change="handleSelectionChange" v-loading="loading">
        <el-table-column type="selection" width="55" />
        <el-table-column prop="id" label="ID" width="80" />
        <el-table-column prop="title" label="标题" show-overflow-tooltip />
        <el-table-column prop="category_id" label="分类" width="100" />
        <el-table-column prop="status" label="状态" width="100">
          <template #default="{ row }">
            <el-tag :type="row.status === 1 ? 'success' : row.status === 0 ? 'warning' : 'danger'">
              {{ row.status === 0 ? '待审核' : row.status === 1 ? '已发布' : '垃圾' }}
            </el-tag>
          </template>
        </el-table-column>
        <el-table-column prop="is_duplicate" label="重复" width="80">
          <template #default="{ row }">
            <el-tag v-if="row.is_duplicate" type="info">重复</el-tag>
            <span v-else>否</span>
          </template>
        </el-table-column>
        <el-table-column prop="create_time" label="创建时间" width="180" />
        <el-table-column label="操作" width="150" fixed="right">
          <template #default="{ row }">
            <el-button link type="primary" @click="handleEdit(row)">编辑</el-button>
            <el-button link type="danger" @click="handleDelete(row)">删除</el-button>
          </template>
        </el-table-column>
      </el-table>
      
      <div class="pagination">
        <el-pagination
          v-model:current-page="page"
          :page-size="pageSize"
          :total="total"
          layout="total, prev, pager, next"
          @current-change="loadArticles"
        />
      </div>
    </div>
    
    <el-dialog v-model="editDialogVisible" title="编辑文章" width="600px">
      <el-form :model="editForm" label-width="80px">
        <el-form-item label="标题">
          <el-input v-model="editForm.title" />
        </el-form-item>
        <el-form-item label="分类">
          <el-select v-model="editForm.category_id">
            <el-option v-for="cat in categories" :key="cat.id" :label="cat.name" :value="cat.id" />
          </el-select>
        </el-form-item>
        <el-form-item label="状态">
          <el-select v-model="editForm.status">
            <el-option label="待审核" :value="0" />
            <el-option label="已发布" :value="1" />
            <el-option label="垃圾内容" :value="2" />
          </el-select>
        </el-form-item>
      </el-form>
      <template #footer>
        <el-button @click="editDialogVisible = false">取消</el-button>
        <el-button type="primary" @click="handleSave">保存</el-button>
      </template>
    </el-dialog>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import { ElMessage, ElMessageBox } from 'element-plus'
import { adminApi } from '@/api/admin'

const loading = ref(false)
const articles = ref([])
const categories = ref([])
const page = ref(1)
const pageSize = ref(20)
const total = ref(0)
const filterStatus = ref(null)
const selectedIds = ref([])
const editDialogVisible = ref(false)
const editForm = ref({
  id: null,
  title: '',
  category_id: 0,
  status: 0
})

const loadArticles = async () => {
  loading.value = true
  try {
    const res = await adminApi.articles.list({
      page: page.value,
      page_size: pageSize.value,
      status: filterStatus.value
    })
    if (res.code === 0) {
      articles.value = res.data.items || []
      total.value = res.data.total || 0
    }
  } catch (error) {
    console.error('Failed to load articles:', error)
  } finally {
    loading.value = false
  }
}

const loadCategories = async () => {
  try {
    const res = await adminApi.categories.list()
    if (res.code === 0) {
      categories.value = res.data || []
    }
  } catch (error) {
    console.error('Failed to load categories:', error)
  }
}

const handleSelectionChange = (selection) => {
  selectedIds.value = selection.map(item => item.id)
}

const handleEdit = (row) => {
  editForm.value = {
    id: row.id,
    title: row.title,
    category_id: row.category_id,
    status: row.status
  }
  editDialogVisible.value = true
}

const handleSave = async () => {
  try {
    await adminApi.articles.edit(editForm.value)
    ElMessage.success('保存成功')
    editDialogVisible.value = false
    loadArticles()
  } catch (error) {
    console.error('Failed to save:', error)
  }
}

const handleDelete = async (row) => {
  try {
    await ElMessageBox.confirm('确定要删除这篇文章吗？')
    await adminApi.articles.delete(row.id)
    ElMessage.success('删除成功')
    loadArticles()
  } catch (error) {
    if (error !== 'cancel') {
      console.error('Failed to delete:', error)
    }
  }
}

const handleBatchDelete = async () => {
  if (selectedIds.value.length === 0) {
    ElMessage.warning('请选择要删除的文章')
    return
  }
  
  try {
    await ElMessageBox.confirm(`确定要删除选中的 ${selectedIds.value.length} 篇文章吗？`)
    await adminApi.articles.batch({ action: 'delete', ids: selectedIds.value })
    ElMessage.success('删除成功')
    loadArticles()
  } catch (error) {
    if (error !== 'cancel') {
      console.error('Failed to batch delete:', error)
    }
  }
}

onMounted(() => {
  loadArticles()
  loadCategories()
})
</script>

<style scoped>
.article-list {
  padding: 20px;
}

.header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 20px;
}

.header h1 {
  margin: 0;
  font-size: 24px;
}

.actions {
  display: flex;
  gap: 10px;
}

.pagination {
  margin-top: 20px;
  display: flex;
  justify-content: flex-end;
}
</style>
