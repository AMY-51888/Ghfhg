<template>
  <div class="dashboard">
    <header class="header">
      <h1>Dashboard</h1>
      <el-button @click="handleLogout">退出登录</el-button>
    </header>
    
    <div class="content">
      <el-row :gutter="20">
        <el-col :span="6">
          <div class="stat-card">
            <div class="stat-value">{{ stats.totalArticles }}</div>
            <div class="stat-label">文章总数</div>
          </div>
        </el-col>
        <el-col :span="6">
          <div class="stat-card">
            <div class="stat-value">{{ stats.todayArticles }}</div>
            <div class="stat-label">今日新增</div>
          </div>
        </el-col>
        <el-col :span="6">
          <div class="stat-card">
            <div class="stat-value">{{ stats.pendingReview }}</div>
            <div class="stat-label">待审核</div>
          </div>
        </el-col>
        <el-col :span="6">
          <div class="stat-card">
            <div class="stat-value">{{ stats.duplicates }}</div>
            <div class="stat-label">重复内容</div>
          </div>
        </el-col>
      </el-row>
      
      <el-card class="mt-20">
        <template #header>
          <span>最近采集日志</span>
        </template>
        <el-table :data="crawlLogs" style="width: 100%">
          <el-table-column prop="task_id" label="任务ID" width="80" />
          <el-table-column prop="count" label="抓取数" width="100" />
          <el-table-column prop="duplicate_count" label="重复数" width="100" />
          <el-table-column prop="status" label="状态" width="100" />
          <el-table-column prop="msg" label="信息" />
          <el-table-column prop="create_time" label="时间" width="180" />
        </el-table>
      </el-card>
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import { useRouter } from 'vue-router'
import { adminApi } from '@/api/admin'

const router = useRouter()
const stats = ref({
  totalArticles: 0,
  todayArticles: 0,
  pendingReview: 0,
  duplicates: 0
})
const crawlLogs = ref([])

const loadDashboard = async () => {
  try {
    const res = await adminApi.crawl.logs({ page_size: 5 })
    if (res.code === 0) {
      crawlLogs.value = res.data.items || []
    }
  } catch (error) {
    console.error('Failed to load dashboard:', error)
  }
}

const handleLogout = () => {
  localStorage.removeItem('admin_token')
  router.push('/admin/login')
}

onMounted(() => {
  loadDashboard()
})
</script>

<style scoped>
.dashboard {
  padding: 20px;
}

.header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 20px;
}

.header h1 {
  margin: 0;
  font-size: 24px;
}

.stat-card {
  background: #fff;
  padding: 30px;
  border-radius: 8px;
  box-shadow: 0 2px 8px rgba(0,0,0,0.08);
  text-align: center;
}

.stat-value {
  font-size: 36px;
  font-weight: bold;
  color: #fe2c55;
}

.stat-label {
  margin-top: 10px;
  color: #666;
}

.mt-20 {
  margin-top: 20px;
}
</style>
