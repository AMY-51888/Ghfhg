<template>
  <div class="keyword-manage">
    <header class="header">
      <h1>关键词管理</h1>
      <el-button type="primary" @click="handleAdd">新增关键词</el-button>
    </header>
    
    <div class="content">
      <el-table :data="keywords" v-loading="loading">
        <el-table-column prop="id" label="ID" width="80" />
        <el-table-column prop="word" label="关键词" />
        <el-table-column prop="category_id" label="对应分类" width="120">
          <template #default="{ row }">
            {{ getCategoryName(row.category_id) }}
          </template>
        </el-table-column>
        <el-table-column prop="weight" label="权重" width="100" />
        <el-table-column label="操作" width="150" fixed="right">
          <template #default="{ row }">
            <el-button link type="primary" @click="handleEdit(row)">编辑</el-button>
          </template>
        </el-table-column>
      </el-table>
    </div>
    
    <el-dialog v-model="dialogVisible" :title="editForm.id ? '编辑关键词' : '新增关键词'" width="400px">
      <el-form :model="editForm" label-width="80px">
        <el-form-item label="关键词">
          <el-input v-model="editForm.word" />
        </el-form-item>
        <el-form-item label="分类">
          <el-select v-model="editForm.category_id">
            <el-option v-for="cat in categories" :key="cat.id" :label="cat.name" :value="cat.id" />
          </el-select>
        </el-form-item>
        <el-form-item label="权重">
          <el-input-number v-model="editForm.weight" :min="1" :max="10" />
        </el-form-item>
      </el-form>
      <template #footer>
        <el-button @click="dialogVisible = false">取消</el-button>
        <el-button type="primary" @click="handleSave">保存</el-button>
      </template>
    </el-dialog>
  </div>
</template>

<script setup>
import { ref, onMounted, computed } from 'vue'
import { ElMessage } from 'element-plus'
import { adminApi } from '@/api/admin'

const loading = ref(false)
const keywords = ref([])
const categories = ref([])
const dialogVisible = ref(false)
const editForm = ref({
  id: null,
  word: '',
  category_id: 1,
  weight: 1
})

const getCategoryName = (id) => {
  const cat = categories.value.find(c => c.id === id)
  return cat ? cat.name : '-'
}

const loadKeywords = async () => {
  loading.value = true
  try {
    const res = await adminApi.keywords.list()
    if (res.code === 0) {
      keywords.value = res.data || []
    }
  } catch (error) {
    console.error('Failed to load keywords:', error)
  } finally {
    loading.value = false
  }
}

const loadCategories = async () => {
  try {
    const res = await adminApi.categories.list()
    if (res.code === 0) {
      categories.value = res.data || []
    }
  } catch (error) {
    console.error('Failed to load categories:', error)
  }
}

const handleAdd = () => {
  editForm.value = { id: null, word: '', category_id: 1, weight: 1 }
  dialogVisible.value = true
}

const handleEdit = (row) => {
  editForm.value = { ...row }
  dialogVisible.value = true
}

const handleSave = async () => {
  try {
    await adminApi.keywords.edit(editForm.value)
    ElMessage.success('保存成功')
    dialogVisible.value = false
    loadKeywords()
  } catch (error) {
    console.error('Failed to save:', error)
  }
}

onMounted(() => {
  loadKeywords()
  loadCategories()
})
</script>

<style scoped>
.keyword-manage {
  padding: 20px;
}

.header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 20px;
}

.header h1 {
  margin: 0;
  font-size: 24px;
}
</style>
