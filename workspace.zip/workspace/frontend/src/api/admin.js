import request from './request'

export const adminApi = {
  login: (data) => request.post('/admin/login', data),
  
  articles: {
    list: (params) => request.get('/admin/articles', { params }),
    edit: (data) => request.post('/admin/article/edit', data),
    delete: (id) => request.post('/admin/article/delete', { id }),
    batch: (data) => request.post('/admin/article/batch', data)
  },
  
  crawl: {
    tasks: () => request.get('/admin/crawl/tasks'),
    start: (params) => request.post('/admin/crawl/start', params),
    stop: (params) => request.post('/admin/crawl/stop', params),
    logs: (params) => request.get('/admin/crawl/logs', { params })
  },
  
  categories: {
    list: () => request.get('/admin/categories'),
    edit: (data) => request.post('/admin/category/edit', data)
  },
  
  keywords: {
    list: (params) => request.get('/admin/keywords', { params }),
    edit: (data) => request.post('/admin/keyword/edit', data)
  },
  
  settings: {
    get: () => request.get('/admin/settings'),
    update: (data) => request.post('/admin/settings/update', data)
  },
  
  duplicates: {
    list: (params) => request.get('/admin/duplicate/list', { params }),
    handle: (data) => request.post('/admin/duplicate/handle', data)
  }
}
