import request from './request'

export const articleApi = {
  list: (params) => request.get('/articles/list', { params }),
  detail: (id) => request.get(`/articles/detail/${id}`),
  category: (id, params) => request.get(`/articles/category/${id}`, { params }),
  search: (params) => request.get('/articles/search', { params })
}

export const homeApi = {
  data: () => request.get('/home')
}

export const categoryApi = {
  list: () => request.get('/categories')
}
