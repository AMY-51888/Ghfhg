import { createRouter, createWebHistory } from 'vue-router'

const routes = [
  {
    path: '/',
    component: () => import('@/views/home/Index.vue'),
    children: [
      { path: '', name: 'Home', component: () => import('@/views/home/Home.vue') },
      { path: 'category/:id', name: 'Category', component: () => import('@/views/home/Category.vue') },
      { path: 'article/:id', name: 'ArticleDetail', component: () => import('@/views/home/ArticleDetail.vue') },
      { path: 'search', name: 'Search', component: () => import('@/views/home/Search.vue') }
    ]
  },
  {
    path: '/admin',
    component: () => import('@/views/admin/Layout.vue'),
    children: [
      { path: 'login', name: 'AdminLogin', component: () => import('@/views/admin/Login.vue') },
      { path: '', name: 'Dashboard', component: () => import('@/views/admin/Dashboard.vue') },
      { path: 'articles', name: 'ArticleManage', component: () => import('@/views/admin/ArticleList.vue') },
      { path: 'crawl', name: 'CrawlManage', component: () => import('@/views/admin/CrawlManage.vue') },
      { path: 'duplicates', name: 'DuplicateManage', component: () => import('@/views/admin/DuplicateList.vue') },
      { path: 'categories', name: 'CategoryManage', component: () => import('@/views/admin/CategoryManage.vue') },
      { path: 'keywords', name: 'KeywordManage', component: () => import('@/views/admin/KeywordManage.vue') },
      { path: 'settings', name: 'Settings', component: () => import('@/views/admin/Settings.vue') }
    ]
  }
]

const router = createRouter({
  history: createWebHistory(),
  routes
})

router.beforeEach((to, from, next) => {
  if (to.path.startsWith('/admin') && to.path !== '/admin/login') {
    const token = localStorage.getItem('admin_token')
    if (!token) {
      next('/admin/login')
      return
    }
  }
  next()
})

export default router
