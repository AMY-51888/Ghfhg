-- TikTok资源资讯聚合平台 数据库初始化脚本

CREATE DATABASE IF NOT EXISTS tiktok_news DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

USE tiktok_news;

-- 文章表
CREATE TABLE IF NOT EXISTS articles (
    id BIGINT PRIMARY KEY AUTO_INCREMENT,
    title VARCHAR(500) NOT NULL COMMENT '标题',
    content MEDIUMTEXT COMMENT '正文',
    cover VARCHAR(1000) COMMENT '封面图',
    source_url VARCHAR(1000) NOT NULL COMMENT '来源链接',
    source_md5 VARCHAR(32) NOT NULL COMMENT 'URL MD5去重',
    category_id INT DEFAULT 0 COMMENT '分类ID',
    tags VARCHAR(500) COMMENT '逗号分隔标签',
    summary VARCHAR(500) COMMENT '摘要',
    author VARCHAR(200) COMMENT '作者',
    publish_time DATETIME COMMENT '发布时间',
    status TINYINT DEFAULT 0 COMMENT '0待审核 1已发布 2垃圾内容',
    is_duplicate TINYINT DEFAULT 0 COMMENT '是否重复',
    sim_hash VARCHAR(64) COMMENT '文本指纹',
    create_time DATETIME DEFAULT CURRENT_TIMESTAMP,
    update_time DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_source_md5 (source_md5),
    INDEX idx_sim_hash (sim_hash(10)),
    INDEX idx_category (category_id),
    INDEX idx_status (status),
    INDEX idx_create_time (create_time)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='文章表';

-- 分类表
CREATE TABLE IF NOT EXISTS categories (
    id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(50) NOT NULL COMMENT '分类名',
    sort INT DEFAULT 0 COMMENT '排序',
    status TINYINT DEFAULT 1 COMMENT '状态',
    create_time DATETIME DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='分类表';

INSERT INTO categories (id, name, sort) VALUES
(1, '运营教程', 1),
(2, '小店电商', 2),
(3, '广告投放', 3),
(4, '工具资源', 4),
(5, '最新资讯', 5),
(6, '模板脚本', 6),
(0, '未分类', 0);

-- 采集任务表
CREATE TABLE IF NOT EXISTS crawl_tasks (
    id INT PRIMARY KEY AUTO_INCREMENT,
    keyword VARCHAR(100) NOT NULL COMMENT '关键词',
    source VARCHAR(50) NOT NULL COMMENT '来源平台',
    status VARCHAR(20) DEFAULT 'idle' COMMENT '运行状态',
    last_crawl_time DATETIME COMMENT '最后爬取时间',
    create_time DATETIME DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='采集任务表';

-- 初始化一些采集任务
INSERT INTO crawl_tasks (keyword, source, status) VALUES
('TikTok运营', 'zhihu', 'idle'),
('TikTok小店', 'xiaohongshu', 'idle'),
('TikTok广告投放', 'toutiao', 'idle'),
('TikTok选品', 'bilibili', 'idle'),
('跨境电商 TikTok', 'zhihu', 'idle');

-- 爬取日志表
CREATE TABLE IF NOT EXISTS crawl_logs (
    id INT PRIMARY KEY AUTO_INCREMENT,
    task_id INT NOT NULL COMMENT '任务ID',
    count INT DEFAULT 0 COMMENT '抓取条数',
    duplicate_count INT DEFAULT 0 COMMENT '重复条数',
    status VARCHAR(20) COMMENT '状态',
    msg TEXT COMMENT '日志信息',
    create_time DATETIME DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='爬取日志表';

-- 关键词规则表
CREATE TABLE IF NOT EXISTS keywords (
    id INT PRIMARY KEY AUTO_INCREMENT,
    word VARCHAR(100) NOT NULL COMMENT '关键词',
    category_id INT NOT NULL COMMENT '对应分类',
    weight INT DEFAULT 1 COMMENT '权重',
    create_time DATETIME DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_category (category_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='关键词规则表';

-- 初始化分类关键词
INSERT INTO keywords (word, category_id, weight) VALUES
-- 运营教程
('起号', 1, 1), ('流量', 1, 1), ('剪辑', 1, 1), ('文案', 1, 1),
('TikTok运营', 1, 2), ('账号运营', 1, 2), ('涨粉', 1, 1), ('热门技巧', 1, 1),

-- 小店电商
('小店', 2, 1), ('佣金', 2, 1), ('选品', 2, 1), ('物流', 2, 1),
('定价', 2, 1), ('TikTok小店', 2, 2), ('跨境电商', 2, 2), ('购物车', 2, 1),

-- 广告投放
('ROI', 3, 1), ('广告', 3, 1), ('投放', 3, 1), ('BC', 3, 1),
('消耗', 3, 1), ('广告投放', 3, 2), ('竞价', 3, 1), ('转化', 3, 1),

-- 工具资源
('工具', 4, 1), ('去水印', 4, 1), ('解析', 4, 1), ('批量', 4, 1),
('下载', 4, 1), ('助手', 4, 1), ('软件', 4, 1), ('免费', 4, 1),

-- 最新资讯
('新规', 5, 1), ('政策', 5, 1), ('更新', 5, 1), ('公告', 5, 1),
('TikTok公告', 5, 2), ('新闻', 5, 1), ('官方', 5, 1), ('发布', 5, 1),

-- 模板脚本
('话术', 6, 1), ('脚本', 6, 1), ('模板', 6, 1), ('资料', 6, 1),
('课程', 6, 1), ('培训', 6, 1), ('教学', 6, 1), ('教程', 6, 1);
