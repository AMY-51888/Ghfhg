#!/bin/bash

# TikTok资源资讯聚合平台 - 手动执行一次爬虫脚本

echo "Starting manual crawl..."

# 检查 Python 环境
if ! command -v python3 &> /dev/null; then
    echo "Error: Python3 is not installed"
    exit 1
fi

# 设置工作目录
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_DIR="$(dirname "$SCRIPT_DIR")"

cd "$PROJECT_DIR/backend"

# 检查虚拟环境
if [ -d "venv" ]; then
    source venv/bin/activate
fi

# 运行爬虫
echo "Running spider for keyword: TikTok运营"
python -c "
import asyncio
from app.spiders.zhihu import ZhihuSpider

async def main():
    spider = ZhihuSpider()
    items = await spider.crawl('TikTok运营')
    print(f'Crawled {len(items)} items')
    await spider.close()

asyncio.run(main())
"

echo "Crawl completed!"
