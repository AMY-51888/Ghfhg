from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from app.core.config import settings
from app.api import articles, categories, home
from app.api.admin import login, article, crawl, settings as admin_settings
from app.api.callback import crawl as crawl_callback

app = FastAPI(
    title="TikTok资源资讯聚合平台 API",
    version="1.0.0",
    description="TikTok资源资讯聚合平台后端API服务"
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(home.router, prefix="/api", tags=["首页"])
app.include_router(articles.router, prefix="/api/articles", tags=["文章"])
app.include_router(categories.router, prefix="/api", tags=["分类"])
app.include_router(login.router, prefix="/admin", tags=["管理后台-登录"])
app.include_router(article.router, prefix="/admin", tags=["管理后台-文章"])
app.include_router(crawl.router, prefix="/admin", tags=["管理后台-采集"])
app.include_router(admin_settings.router, prefix="/admin", tags=["管理后台-设置"])
app.include_router(crawl_callback.router, prefix="/api/callback", tags=["采集回调"])


@app.get("/")
async def root():
    return {"message": "TikTok资源资讯聚合平台 API", "version": "1.0.0"}


@app.get("/health")
async def health():
    return {"status": "healthy"}


if __name__ == "__main__":
    import uvicorn
    uvicorn.run("main:app", host="0.0.0.0", port=8000, reload=True)
