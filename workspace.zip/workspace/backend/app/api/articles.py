from fastapi import APIRouter, Depends, Query
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from app.core.database import get_db
from app.models.article import Article
from app.models.category import Category
from app.schemas import ArticleListResponse, PageResponse
from typing import Optional

router = APIRouter()


@router.get("/list", response_model=PageResponse)
async def get_articles(
    page: int = Query(1, ge=1),
    page_size: int = Query(20, ge=1, le=100),
    category_id: Optional[int] = None,
    status: Optional[int] = None,
    sort: str = Query("create_time"),
    db: AsyncSession = Depends(get_db)
):
    query = select(Article).where(Article.status == 1)
    
    if category_id is not None:
        query = query.where(Article.category_id == category_id)
    if status is not None:
        query = query.where(Article.status == status)
    
    if sort == "publish_time":
        query = query.order_by(Article.publish_time.desc())
    else:
        query = query.order_by(Article.create_time.desc())
    
    count_query = select(Article.id).where(Article.status == 1)
    if category_id is not None:
        count_query = count_query.where(Article.category_id == category_id)
    
    offset = (page - 1) * page_size
    query = query.offset(offset).limit(page_size)
    
    result = await db.execute(query)
    articles = result.scalars().all()
    
    count_result = await db.execute(count_query)
    total = len(count_result.scalars().all())
    
    return PageResponse(
        items=[ArticleListResponse.model_validate(a) for a in articles],
        total=total,
        page=page,
        page_size=page_size
    )


@router.get("/detail/{article_id}")
async def get_article_detail(article_id: int, db: AsyncSession = Depends(get_db)):
    result = await db.execute(select(Article).where(Article.id == article_id))
    article = result.scalar_one_or_none()
    
    if not article:
        return {"code": 1002, "message": "Article not found"}
    
    category_result = await db.execute(
        select(Category).where(Category.id == article.category_id)
    )
    category = category_result.scalar_one_or_none()
    
    return {
        "code": 0,
        "message": "success",
        "data": {
            "id": article.id,
            "title": article.title,
            "content": article.content,
            "cover": article.cover,
            "source_url": article.source_url,
            "category_id": article.category_id,
            "category_name": category.name if category else "未分类",
            "tags": article.tags,
            "summary": article.summary,
            "author": article.author,
            "publish_time": article.publish_time,
            "create_time": article.create_time
        }
    }


@router.get("/category/{category_id}")
async def get_articles_by_category(
    category_id: int,
    page: int = Query(1, ge=1),
    page_size: int = Query(20, ge=1, le=100),
    db: AsyncSession = Depends(get_db)
):
    return await get_articles(page, page_size, category_id, 1, "create_time", db)


@router.get("/search")
async def search_articles(
    q: str = Query(..., min_length=1),
    page: int = Query(1, ge=1),
    page_size: int = Query(20, ge=1, le=100),
    db: AsyncSession = Depends(get_db)
):
    query = select(Article).where(
        Article.status == 1,
        (Article.title.contains(q) | Article.content.contains(q))
    ).order_by(Article.create_time.desc())
    
    offset = (page - 1) * page_size
    query = query.offset(offset).limit(page_size)
    
    result = await db.execute(query)
    articles = result.scalars().all()
    
    return PageResponse(
        items=[ArticleListResponse.model_validate(a) for a in articles],
        total=len(articles),
        page=page,
        page_size=page_size
    )
