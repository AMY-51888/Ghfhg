from fastapi import APIRouter, Depends
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, func
from app.core.database import get_db
from app.models.article import Article
from app.models.category import Category

router = APIRouter()


@router.get("/home")
async def get_home_data(db: AsyncSession = Depends(get_db)):
    latest_query = select(Article).where(
        Article.status == 1
    ).order_by(Article.create_time.desc()).limit(10)
    latest_result = await db.execute(latest_query)
    latest_articles = latest_result.scalars().all()
    
    hot_query = select(Article).where(
        Article.status == 1
    ).order_by(Article.publish_time.desc()).limit(10)
    hot_result = await db.execute(hot_query)
    hot_articles = hot_result.scalars().all()
    
    category_query = select(
        Category.id,
        Category.name,
        func.count(Article.id).label("count")
    ).outerjoin(
        Article, Article.category_id == Category.id
    ).where(
        Category.status == 1
    ).group_by(Category.id, Category.name).order_by(Category.sort)
    category_result = await db.execute(category_query)
    categories = category_result.all()
    
    return {
        "code": 0,
        "message": "success",
        "data": {
            "latest_articles": [
                {
                    "id": a.id,
                    "title": a.title,
                    "cover": a.cover,
                    "summary": a.summary,
                    "publish_time": a.publish_time
                }
                for a in latest_articles
            ],
            "hot_articles": [
                {
                    "id": a.id,
                    "title": a.title,
                    "cover": a.cover,
                    "summary": a.summary,
                    "publish_time": a.publish_time
                }
                for a in hot_articles
            ],
            "categories": [
                {"id": c.id, "name": c.name, "count": c.count}
                for c in categories
            ]
        }
    }
