from fastapi import APIRouter, Depends, Query
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, delete
from app.core.database import get_db
from app.core.security import get_current_user
from app.models.article import Article
from app.schemas import PageResponse, ArticleUpdate, BatchRequest
from typing import Optional

router = APIRouter()


@router.get("/articles")
async def get_admin_articles(
    page: int = Query(1, ge=1),
    page_size: int = Query(20, ge=1, le=100),
    category_id: Optional[int] = None,
    status: Optional[int] = None,
    is_duplicate: Optional[int] = None,
    keyword: Optional[str] = None,
    db: AsyncSession = Depends(get_db),
    current_user: dict = Depends(get_current_user)
):
    query = select(Article)
    
    if category_id is not None:
        query = query.where(Article.category_id == category_id)
    if status is not None:
        query = query.where(Article.status == status)
    if is_duplicate is not None:
        query = query.where(Article.is_duplicate == is_duplicate)
    if keyword:
        query = query.where(Article.title.contains(keyword))
    
    query = query.order_by(Article.create_time.desc())
    offset = (page - 1) * page_size
    query = query.offset(offset).limit(page_size)
    
    result = await db.execute(query)
    articles = result.scalars().all()
    
    count_query = select(Article.id)
    if category_id is not None:
        count_query = count_query.where(Article.category_id == category_id)
    if status is not None:
        count_query = count_query.where(Article.status == status)
    count_result = await db.execute(count_query)
    total = len(count_result.scalars().all())
    
    return {
        "code": 0,
        "message": "success",
        "data": {
            "items": [
                {
                    "id": a.id,
                    "title": a.title,
                    "cover": a.cover,
                    "category_id": a.category_id,
                    "status": a.status,
                    "is_duplicate": a.is_duplicate,
                    "create_time": a.create_time
                }
                for a in articles
            ],
            "total": total,
            "page": page,
            "page_size": page_size
        }
    }


@router.post("/article/edit")
async def edit_article(
    article_data: ArticleUpdate,
    db: AsyncSession = Depends(get_db),
    current_user: dict = Depends(get_current_user)
):
    if not article_data.id:
        return {"code": 1001, "message": "Article ID is required"}
    
    result = await db.execute(select(Article).where(Article.id == article_data.id))
    article = result.scalar_one_or_none()
    
    if not article:
        return {"code": 1002, "message": "Article not found"}
    
    update_data = article_data.model_dump(exclude_unset=True)
    for key, value in update_data.items():
        if value is not None and key != "id":
            setattr(article, key, value)
    
    await db.commit()
    
    return {"code": 0, "message": "success"}


@router.post("/article/delete")
async def delete_article(
    id: int,
    db: AsyncSession = Depends(get_db),
    current_user: dict = Depends(get_current_user)
):
    result = await db.execute(delete(Article).where(Article.id == id))
    await db.commit()
    
    return {"code": 0, "message": "success"}


@router.post("/article/batch")
async def batch_article(
    request: BatchRequest,
    db: AsyncSession = Depends(get_db),
    current_user: dict = Depends(get_current_user)
):
    if request.action == "delete":
        for article_id in request.ids:
            await db.execute(delete(Article).where(Article.id == article_id))
    elif request.action == "publish":
        for article_id in request.ids:
            result = await db.execute(select(Article).where(Article.id == article_id))
            article = result.scalar_one_or_none()
            if article:
                article.status = 1
    elif request.action == "category" and request.category_id is not None:
        for article_id in request.ids:
            result = await db.execute(select(Article).where(Article.id == article_id))
            article = result.scalar_one_or_none()
            if article:
                article.category_id = request.category_id
    
    await db.commit()
    
    return {"code": 0, "message": "success"}
