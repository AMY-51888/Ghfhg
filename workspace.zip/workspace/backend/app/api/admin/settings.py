from fastapi import APIRouter, Depends
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from app.core.database import get_db
from app.core.security import get_current_user
from app.models.category import Category
from app.models.keyword import Keyword
from app.schemas import CategoryCreate

router = APIRouter()


@router.get("/categories")
async def get_admin_categories(
    db: AsyncSession = Depends(get_db),
    current_user: dict = Depends(get_current_user)
):
    result = await db.execute(
        select(Category).order_by(Category.sort)
    )
    categories = result.scalars().all()
    
    return {
        "code": 0,
        "message": "success",
        "data": [
            {
                "id": c.id,
                "name": c.name,
                "sort": c.sort,
                "status": c.status
            }
            for c in categories
        ]
    }


@router.post("/category/edit")
async def edit_category(
    category_data: CategoryCreate,
    id: int = None,
    db: AsyncSession = Depends(get_db),
    current_user: dict = Depends(get_current_user)
):
    if id:
        result = await db.execute(select(Category).where(Category.id == id))
        category = result.scalar_one_or_none()
        if category:
            category.name = category_data.name
            category.sort = category_data.sort
            category.status = category_data.status
    else:
        category = Category(
            name=category_data.name,
            sort=category_data.sort,
            status=category_data.status
        )
        db.add(category)
    
    await db.commit()
    
    return {"code": 0, "message": "success"}


@router.get("/keywords")
async def get_keywords(
    category_id: int = None,
    db: AsyncSession = Depends(get_db),
    current_user: dict = Depends(get_current_user)
):
    query = select(Keyword)
    if category_id is not None:
        query = query.where(Keyword.category_id == category_id)
    
    result = await db.execute(query)
    keywords = result.scalars().all()
    
    return {
        "code": 0,
        "message": "success",
        "data": [
            {
                "id": k.id,
                "word": k.word,
                "category_id": k.category_id,
                "weight": k.weight
            }
            for k in keywords
        ]
    }


@router.post("/keyword/edit")
async def edit_keyword(
    word: str,
    category_id: int,
    weight: int = 1,
    id: int = None,
    db: AsyncSession = Depends(get_db),
    current_user: dict = Depends(get_current_user)
):
    if id:
        result = await db.execute(select(Keyword).where(Keyword.id == id))
        keyword = result.scalar_one_or_none()
        if keyword:
            keyword.word = word
            keyword.category_id = category_id
            keyword.weight = weight
    else:
        keyword = Keyword(
            word=word,
            category_id=category_id,
            weight=weight
        )
        db.add(keyword)
    
    await db.commit()
    
    return {"code": 0, "message": "success"}


@router.get("/settings")
async def get_settings(
    current_user: dict = Depends(get_current_user)
):
    return {
        "code": 0,
        "message": "success",
        "data": {
            "site_name": "TikTok资源资讯聚合",
            "site_url": "https://example.com",
            "seo_title": "TikTok资源资讯聚合平台",
            "seo_keywords": "TikTok,跨境电商,运营教程",
            "seo_description": "专业的TikTok资源资讯聚合平台",
            "site_logo": "/uploads/logo.png"
        }
    }


@router.post("/settings/update")
async def update_settings(
    settings_data: dict,
    current_user: dict = Depends(get_current_user)
):
    return {"code": 0, "message": "success"}
