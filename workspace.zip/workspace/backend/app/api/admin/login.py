from fastapi import APIRouter, HTTPException, status
from app.core.security import verify_admin, create_access_token
from app.schemas import LoginRequest, LoginResponse
from datetime import timedelta

router = APIRouter()


@router.post("/login", response_model=LoginResponse)
async def login(request: LoginRequest):
    if not verify_admin(request.username, request.password):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid username or password"
        )
    
    access_token = create_access_token(
        data={"sub": request.username},
        expires_delta=timedelta(minutes=1440)
    )
    
    return LoginResponse(token=access_token, expires_in=86400)
