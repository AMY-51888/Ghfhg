from fastapi import APIRouter, Depends, Query
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, update
from app.core.database import get_db
from app.core.security import get_current_user
from app.core.redis import get_redis
from app.models.crawl import CrawlTask, CrawlLog
from app.schemas import CrawlTaskResponse, CrawlLogResponse
from typing import Optional
import json

router = APIRouter()


@router.get("/crawl/tasks")
async def get_crawl_tasks(
    db: AsyncSession = Depends(get_db),
    current_user: dict = Depends(get_current_user)
):
    result = await db.execute(
        select(CrawlTask).order_by(CrawlTask.create_time.desc())
    )
    tasks = result.scalars().all()
    
    return {
        "code": 0,
        "message": "success",
        "data": [
            {
                "id": t.id,
                "keyword": t.keyword,
                "source": t.source,
                "status": t.status,
                "last_crawl_time": t.last_crawl_time,
                "create_time": t.create_time
            }
            for t in tasks
        ]
    }


@router.post("/crawl/start")
async def start_crawl_task(
    task_id: Optional[int] = None,
    all: bool = False,
    db: AsyncSession = Depends(get_db),
    current_user: dict = Depends(get_current_user)
):
    redis_client = get_redis()
    
    if all:
        result = await db.execute(select(CrawlTask))
        tasks = result.scalars().all()
        for task in tasks:
            await redis_client.set(f"crawl_task:{task.id}:running", "true")
            await db.execute(
                update(CrawlTask)
                .where(CrawlTask.id == task.id)
                .values(status="running")
            )
    elif task_id:
        await redis_client.set(f"crawl_task:{task_id}:running", "true")
        await db.execute(
            update(CrawlTask)
            .where(CrawlTask.id == task_id)
            .values(status="running")
        )
    
    await db.commit()
    
    return {"code": 0, "message": "success"}


@router.post("/crawl/stop")
async def stop_crawl_task(
    task_id: int,
    db: AsyncSession = Depends(get_db),
    current_user: dict = Depends(get_current_user)
):
    redis_client = get_redis()
    await redis_client.delete(f"crawl_task:{task_id}:running")
    await db.execute(
        update(CrawlTask)
        .where(CrawlTask.id == task_id)
        .values(status="idle")
    )
    await db.commit()
    
    return {"code": 0, "message": "success"}


@router.get("/crawl/logs")
async def get_crawl_logs(
    task_id: Optional[int] = None,
    page: int = Query(1, ge=1),
    page_size: int = Query(20, ge=1, le=100),
    db: AsyncSession = Depends(get_db),
    current_user: dict = Depends(get_current_user)
):
    query = select(CrawlLog).order_by(CrawlLog.create_time.desc())
    
    if task_id is not None:
        query = query.where(CrawlLog.task_id == task_id)
    
    offset = (page - 1) * page_size
    query = query.offset(offset).limit(page_size)
    
    result = await db.execute(query)
    logs = result.scalars().all()
    
    return {
        "code": 0,
        "message": "success",
        "data": {
            "items": [
                {
                    "id": log.id,
                    "task_id": log.task_id,
                    "count": log.count,
                    "duplicate_count": log.duplicate_count,
                    "status": log.status,
                    "msg": log.msg,
                    "create_time": log.create_time
                }
                for log in logs
            ],
            "total": len(logs),
            "page": page,
            "page_size": page_size
        }
    }
