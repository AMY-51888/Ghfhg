from fastapi import APIRouter, Depends
from sqlalchemy.ext.asyncio import AsyncSession
from app.core.database import get_db
from app.schemas import CrawlCallbackRequest

router = APIRouter()


@router.post("/crawl_finish")
async def crawl_finish_callback(
    request: CrawlCallbackRequest,
    db: AsyncSession = Depends(get_db)
):
    return {"code": 0, "message": "success"}
