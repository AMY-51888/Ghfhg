from fastapi import APIRouter, Depends
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from app.core.database import get_db
from app.models.category import Category
from typing import List

router = APIRouter()


@router.get("/categories")
async def get_categories(db: AsyncSession = Depends(get_db)):
    result = await db.execute(
        select(Category).where(Category.status == 1).order_by(Category.sort)
    )
    categories = result.scalars().all()
    
    return {
        "code": 0,
        "message": "success",
        "data": [
            {"id": c.id, "name": c.name, "sort": c.sort}
            for c in categories
        ]
    }
