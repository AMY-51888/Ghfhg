from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from app.models.keyword import Keyword
from collections import defaultdict


class ClassifyService:
    CATEGORY_KEYWORDS = {
        1: ["起号", "流量", "剪辑", "文案", "运营", "账号", "涨粉", "热门", "技巧"],
        2: ["小店", "佣金", "选品", "物流", "定价", "电商", "跨境", "购物车", "商品"],
        3: ["ROI", "广告", "投放", "BC", "消耗", "竞价", "转化", "点击", " CPM"],
        4: ["工具", "去水印", "解析", "批量", "下载", "助手", "软件", "免费"],
        5: ["新规", "政策", "更新", "公告", "新闻", "官方", "发布", "动态"],
        6: ["话术", "脚本", "模板", "资料", "课程", "培训", "教学", "教程"]
    }
    
    @classmethod
    async def get_category_weights(cls, db: AsyncSession) -> dict:
        result = await db.execute(select(Keyword))
        keywords = result.scalars().all()
        
        weights = defaultdict(list)
        for kw in keywords:
            weights[kw.category_id].append(kw.word)
        
        if not weights:
            weights = cls.CATEGORY_KEYWORDS
        
        return weights
    
    @classmethod
    async def classify(cls, db: AsyncSession, title: str, content: str) -> int:
        text = (title + " " + content).lower()
        
        weights = await cls.get_category_weights(db)
        
        scores = defaultdict(int)
        for cat_id, keywords in weights.items():
            for keyword in keywords:
                if keyword.lower() in text:
                    scores[cat_id] += 1
        
        if not scores:
            return 0
        
        max_score = max(scores.values())
        if max_score == 0:
            return 0
        
        for cat_id, score in scores.items():
            if score == max_score:
                return cat_id
        
        return 0
    
    @staticmethod
    def extract_tags(title: str, content: str, max_tags: int = 5) -> str:
        text = (title + " " + content).lower()
        
        important_words = [
            "tiktok", "抖音", "运营", "电商", "跨境", "选品",
            "广告", "投放", "变现", "引流", "流量", "账号",
            "小店", "视频", "内容", "创作", "涨粉", "技巧"
        ]
        
        tags = []
        for word in important_words:
            if word in text and len(tags) < max_tags:
                tags.append(word)
        
        return ",".join(tags)
