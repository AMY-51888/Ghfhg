from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, update, delete
from app.models.article import Article
from typing import Optional, List
import hashlib


class ArticleService:
    @staticmethod
    async def create_article(
        db: AsyncSession,
        title: str,
        content: str,
        source_url: str,
        cover: Optional[str] = None,
        author: Optional[str] = None,
        publish_time=None,
        category_id: int = 0,
        tags: Optional[str] = None,
        summary: Optional[str] = None,
        sim_hash: Optional[str] = None
    ) -> Article:
        source_md5 = hashlib.md5(source_url.encode()).hexdigest()
        
        article = Article(
            title=title,
            content=content,
            cover=cover,
            source_url=source_url,
            source_md5=source_md5,
            category_id=category_id,
            tags=tags,
            summary=summary,
            author=author,
            publish_time=publish_time,
            sim_hash=sim_hash,
            status=0,
            is_duplicate=0
        )
        
        db.add(article)
        await db.commit()
        await db.refresh(article)
        
        return article
    
    @staticmethod
    async def get_article(db: AsyncSession, article_id: int) -> Optional[Article]:
        result = await db.execute(
            select(Article).where(Article.id == article_id)
        )
        return result.scalar_one_or_none()
    
    @staticmethod
    async def update_article(
        db: AsyncSession,
        article_id: int,
        **kwargs
    ) -> bool:
        result = await db.execute(
            update(Article).where(Article.id == article_id).values(**kwargs)
        )
        await db.commit()
        return result.rowcount > 0
    
    @staticmethod
    async def delete_article(db: AsyncSession, article_id: int) -> bool:
        result = await db.execute(
            delete(Article).where(Article.id == article_id)
        )
        await db.commit()
        return result.rowcount > 0
    
    @staticmethod
    async def list_articles(
        db: AsyncSession,
        page: int = 1,
        page_size: int = 20,
        category_id: Optional[int] = None,
        status: Optional[int] = None
    ) -> tuple:
        query = select(Article)
        
        if category_id is not None:
            query = query.where(Article.category_id == category_id)
        if status is not None:
            query = query.where(Article.status == status)
        
        query = query.order_by(Article.create_time.desc())
        query = query.offset((page - 1) * page_size).limit(page_size)
        
        result = await db.execute(query)
        articles = result.scalars().all()
        
        count_query = select(Article.id)
        if category_id is not None:
            count_query = count_query.where(Article.category_id == category_id)
        if status is not None:
            count_query = count_query.where(Article.status == status)
        
        count_result = await db.execute(count_query)
        total = len(count_result.scalars().all())
        
        return articles, total
