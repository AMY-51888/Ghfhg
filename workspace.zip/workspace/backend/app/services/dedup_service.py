from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, and_
from app.models.article import Article
from app.core.redis import get_redis
import hashlib


class DedupService:
    @staticmethod
    def get_url_md5(url: str) -> str:
        return hashlib.md5(url.encode()).hexdigest()
    
    @staticmethod
    async def check_url_duplicate(db: AsyncSession, url: str) -> bool:
        url_md5 = hashlib.md5(url.encode()).hexdigest()
        result = await db.execute(
            select(Article).where(Article.source_md5 == url_md5)
        )
        return result.scalar_one_or_none() is not None
    
    @staticmethod
    async def check_title_similar(db: AsyncSession, title: str, threshold: float = 0.85) -> bool:
        result = await db.execute(
            select(Article).where(Article.status == 1).limit(100)
        )
        articles = result.scalars().all()
        
        for article in articles:
            similarity = DedupService._calculate_title_similarity(title, article.title)
            if similarity > threshold:
                return True
        return False
    
    @staticmethod
    def _calculate_title_similarity(title1: str, title2: str) -> float:
        words1 = set(title1.lower())
        words2 = set(title2.lower())
        
        if not words1 or not words2:
            return 0.0
        
        intersection = words1 & words2
        union = words1 | words2
        
        return len(intersection) / len(union)
    
    @staticmethod
    async def check_sim_hash(db: AsyncSession, sim_hash: str, threshold: int = 5) -> bool:
        result = await db.execute(
            select(Article).where(
                and_(Article.sim_hash.isnot(None), Article.status == 1)
            ).limit(100)
        )
        articles = result.scalars().all()
        
        for article in articles:
            distance = DedupService._hamming_distance(sim_hash, article.sim_hash)
            if distance < threshold:
                return True
        return False
    
    @staticmethod
    def _hamming_distance(hash1: str, hash2: str) -> int:
        if len(hash1) != len(hash2):
            return 100
        return sum(c1 != c2 for c1, c2 in zip(hash1, hash2))
    
    @staticmethod
    async def is_duplicate(db: AsyncSession, title: str, content: str, url: str) -> tuple:
        url_md5 = DedupService.get_url_md5(url)
        
        if await DedupService.check_url_duplicate(db, url):
            return True, "URL duplicate"
        
        if await DedupService.check_title_similar(db, title):
            return True, "Title similar"
        
        from app.utils.simhash import SimHash
        sim_hasher = SimHash()
        content_hash = sim_hasher.get_hash(content)
        
        if await DedupService.check_sim_hash(db, content_hash):
            return True, "SimHash duplicate"
        
        return False, ""
