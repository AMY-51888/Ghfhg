import re
from typing import Optional
from app.services.classify_service import ClassifyService


class ContentProcessor:
    @staticmethod
    def clean_content(content: str) -> str:
        content = re.sub(r'http[s]?://\S+', '', content)
        content = re.sub(r'\[图片\d*\]', '', content)
        content = re.sub(r'二维码[^\u4e00-\u9fa5]*', '', content)
        content = re.sub(r'公众号[^\u4e00-\u9fa5]*', '', content)
        content = re.sub(r'微信号[^\u4e00-\u9fa5]*', '', content)
        content = re.sub(r'@[\w]+', '', content)
        content = re.sub(r'\s+', ' ', content)
        
        return content.strip()
    
    @staticmethod
    def extract_summary(content: str, max_length: int = 120) -> str:
        clean = ContentProcessor.clean_content(content)
        
        if len(clean) <= max_length:
            return clean
        
        summary = clean[:max_length]
        
        last_punct = max(summary.rfind('。'), summary.rfind('，'), summary.rfind('！'))
        if last_punct > max_length * 0.6:
            return summary[:last_punct + 1]
        
        return summary + "..."
    
    @staticmethod
    def format_content(content: str) -> str:
        paragraphs = content.split('\n')
        
        formatted = []
        for p in paragraphs:
            p = p.strip()
            if p:
                formatted.append(f'<p>{p}</p>')
        
        return '\n'.join(formatted)
    
    @staticmethod
    def process(title: str, content: str, db=None) -> dict:
        cleaned = ContentProcessor.clean_content(content)
        summary = ContentProcessor.extract_summary(cleaned)
        formatted = ContentProcessor.format_content(cleaned)
        
        tags = ""
        if db:
            tags = ClassifyService.extract_tags(title, content)
        
        return {
            "cleaned_content": cleaned,
            "formatted_content": formatted,
            "summary": summary,
            "tags": tags
        }
