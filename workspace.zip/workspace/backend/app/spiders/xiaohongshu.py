from app.spiders.base import BaseSpider
from typing import Optional, Dict


class XiaohongshuSpider(BaseSpider):
    name = "xiaohongshu"
    source = "xiaohongshu"
    
    def build_search_url(self, keyword: str) -> str:
        encoded_keyword = keyword.replace(' ', '%20')
        return f"https://www.xiaohongshu.com/search_result?keyword={encoded_keyword}&type=51"
    
    def get_item_selector(self) -> str:
        return "div.note-item"
    
    def parse_item(self, element) -> Optional[Dict]:
        try:
            title_elem = element.find('div', class_='title')
            title = title_elem.text.strip() if title_elem else ""
            
            link_tag = element.find('a')
            url = "https://www.xiaohongshu.com" + link_tag['href'] if link_tag else ""
            
            content_elem = element.find('div', class_='desc')
            content = content_elem.text.strip() if content_elem else ""
            
            author_elem = element.find('div', class_='author')
            author = author_elem.text.strip() if author_elem else ""
            
            return {
                'title': title,
                'content': content,
                'url': url,
                'author': author
            }
        except Exception:
            return None
