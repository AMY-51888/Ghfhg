from app.spiders.base import BaseSpider
from typing import Optional, Dict


class BilibiliSpider(BaseSpider):
    name = "bilibili"
    source = "bilibili"
    
    def build_search_url(self, keyword: str) -> str:
        encoded_keyword = keyword.replace(' ', '%20')
        return f"https://search.bilibili.com/all?keyword={encoded_keyword}&order=pubdate"
    
    def get_item_selector(self) -> str:
        return "li.video-item"
    
    def parse_item(self, element) -> Optional[Dict]:
        try:
            title_elem = element.find('a', class_='title')
            title = title_elem.text.strip() if title_elem else ""
            
            url = "https://bilibili.com" + title_elem['href'] if title_elem else ""
            
            desc_elem = element.find('p', class_='description')
            content = desc_elem.text.strip() if desc_elem else ""
            
            author_elem = element.find('span', class_='up-name')
            author = author_elem.text.strip() if author_elem else ""
            
            time_elem = element.find('span', class_='time')
            publish_time = time_elem.text.strip() if time_elem else ""
            
            return {
                'title': title,
                'content': content,
                'url': url,
                'author': author,
                'publish_time': publish_time
            }
        except Exception:
            return None
