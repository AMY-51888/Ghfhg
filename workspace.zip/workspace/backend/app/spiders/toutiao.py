from app.spiders.base import BaseSpider
from typing import Optional, Dict


class ToutiaoSpider(BaseSpider):
    name = "toutiao"
    source = "toutiao"
    
    def build_search_url(self, keyword: str) -> str:
        encoded_keyword = keyword.replace(' ', '%20')
        return f"https://so.toutiao.com/search?keyword={encoded_keyword}"
    
    def get_item_selector(self) -> str:
        return "div.article"
    
    def parse_item(self, element) -> Optional[Dict]:
        try:
            title_elem = element.find('div', class_='article-title')
            title = title_elem.text.strip() if title_elem else ""
            
            link_tag = element.find('a')
            url = link_tag['href'] if link_tag else ""
            
            content_elem = element.find('div', class_='article-content')
            content = content_elem.text.strip() if content_elem else ""
            
            author_elem = element.find('span', class_='author')
            author = author_elem.text.strip() if author_elem else ""
            
            time_elem = element.find('span', class_='time')
            publish_time = time_elem.text.strip() if time_elem else ""
            
            return {
                'title': title,
                'content': content,
                'url': url,
                'author': author,
                'publish_time': publish_time
            }
        except Exception:
            return None
