from abc import ABC, abstractmethod
from typing import List, Dict, Optional
import httpx
from bs4 import BeautifulSoup
from app.services.content_processor import ContentProcessor
from app.utils.simhash import SimHash


class BaseSpider(ABC):
    name: str = "base"
    source: str = "base"
    
    def __init__(self):
        self.client = httpx.AsyncClient(timeout=30.0)
        self.content_processor = ContentProcessor()
        self.sim_hasher = SimHash()
    
    async def crawl(self, keyword: str) -> List[Dict]:
        search_url = self.build_search_url(keyword)
        items = await self.fetch_items(search_url)
        return items
    
    @abstractmethod
    def build_search_url(self, keyword: str) -> str:
        pass
    
    @abstractmethod
    async def fetch_items(self, url: str) -> List[Dict]:
        pass
    
    async def parse(self, response_text: str) -> List[Dict]:
        soup = BeautifulSoup(response_text, 'lxml')
        items = []
        
        for item in soup.find_all(self.get_item_selector()):
            parsed = self.parse_item(item)
            if parsed:
                items.append(parsed)
        
        return items
    
    @abstractmethod
    def get_item_selector(self) -> str:
        pass
    
    @abstractmethod
    def parse_item(self, element) -> Optional[Dict]:
        pass
    
    def normalize(self, item: Dict) -> Dict:
        processed = ContentProcessor.process(item.get('title', ''), item.get('content', ''))
        
        return {
            'title': item.get('title', ''),
            'content': processed['formatted_content'],
            'cover': item.get('cover'),
            'source_url': item.get('url', ''),
            'author': item.get('author'),
            'publish_time': item.get('publish_time'),
            'summary': processed['summary'],
            'tags': processed['tags'],
            'sim_hash': self.sim_hasher.get_hash(item.get('content', ''))
        }
    
    async def close(self):
        await self.client.aclose()
