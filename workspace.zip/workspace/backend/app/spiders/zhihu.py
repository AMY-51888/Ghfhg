from app.spiders.base import BaseSpider
from typing import Optional, Dict
import re


class ZhihuSpider(BaseSpider):
    name = "zhihu"
    source = "zhihu"
    
    def build_search_url(self, keyword: str) -> str:
        encoded_keyword = keyword.replace(' ', '%20')
        return f"https://www.zhihu.com/search?type=content&q={encoded_keyword}"
    
    def get_item_selector(self) -> str:
        return "div.List-item"
    
    def parse_item(self, element) -> Optional[Dict]:
        try:
            title_elem = element.find('h2', class_='ContentItem-title')
            title = title_elem.text.strip() if title_elem else ""
            
            title_tag = title_elem.find('a') if title_elem else None
            url = "https://www.zhihu.com" + title_tag['href'] if title_tag else ""
            
            content_elem = element.find('span', class_='RichText')
            content = content_elem.text.strip() if content_elem else ""
            
            author_elem = element.find('span', class_='UserLink-name')
            author = author_elem.text.strip() if author_elem else ""
            
            time_elem = element.find('time')
            publish_time = time_elem['datetime'] if time_elem and time_elem.has_attr('datetime') else None
            
            return {
                'title': title,
                'content': content,
                'url': url,
                'author': author,
                'publish_time': publish_time
            }
        except Exception:
            return None
