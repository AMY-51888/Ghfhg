from typing import List, Set


class TextSimilarity:
    @staticmethod
    def cosine_similarity(text1: str, text2: str) -> float:
        words1 = set(TextSimilarity._normalize(text1))
        words2 = set(TextSimilarity._normalize(text2))
        
        if not words1 or not words2:
            return 0.0
        
        intersection = words1 & words2
        
        norm1 = len(words1) ** 0.5
        norm2 = len(words2) ** 0.5
        
        return len(intersection) / (norm1 * norm2)
    
    @staticmethod
    def jaccard_similarity(text1: str, text2: str) -> float:
        words1 = set(TextSimilarity._normalize(text1))
        words2 = set(TextSimilarity._normalize(text2))
        
        if not words1 or not words2:
            return 0.0
        
        intersection = words1 & words2
        union = words1 | words2
        
        return len(intersection) / len(union)
    
    @staticmethod
    def _normalize(text: str) -> List[str]:
        import re
        text = text.lower()
        words = re.findall(r'[\w]+', text)
        return words
    
    @staticmethod
    def are_similar(text1: str, text2: str, threshold: float = 0.85) -> bool:
        similarity = TextSimilarity.cosine_similarity(text1, text2)
        return similarity >= threshold
