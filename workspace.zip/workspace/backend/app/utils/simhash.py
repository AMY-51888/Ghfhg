import hashlib
import jieba
from typing import List


class SimHash:
    def __init__(self, hash_bits: int = 64):
        self.hash_bits = hash_bits
    
    def get_hash(self, text: str) -> str:
        if not text:
            return "0" * self.hash_bits
        
        features = self._tokenize(text)
        hashes = [self._hash_feature(f) for f in features]
        
        v = [0] * self.hash_bits
        for h in hashes:
            for i in range(self.hash_bits):
                v[i] += 1 if (h >> i) & 1 else -1
        
        fingerprint = 0
        for i in range(self.hash_bits):
            if v[i] > 0:
                fingerprint |= (1 << i)
        
        return format(fingerprint, '064b')
    
    def _tokenize(self, text: str) -> List[str]:
        words = jieba.cut(text)
        words = [w for w in words if len(w) > 1]
        return words
    
    def _hash_feature(self, feature: str) -> int:
        h = hashlib.md5(feature.encode('utf-8')).digest()
        return int.from_bytes(h[:8], byteorder='big')
    
    def hamming_distance(self, hash1: str, hash2: str) -> int:
        if len(hash1) != len(hash2):
            return 100
        
        h1 = int(hash1, 16) if hash1.startswith('0x') else int(hash1, 16)
        h2 = int(hash2, 16) if hash2.startswith('0x') else int(hash2, 16)
        
        xor = h1 ^ h2
        distance = 0
        
        while xor:
            distance += 1
            xor &= (xor - 1)
        
        return distance
    
    def is_similar(self, hash1: str, hash2: str, threshold: int = 5) -> bool:
        return self.hamming_distance(hash1, hash2) < threshold
