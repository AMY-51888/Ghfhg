import httpx
import hashlib
import os
from typing import Optional
from datetime import datetime


class ImageHandler:
    def __init__(self, storage_path: str = "./uploads/images"):
        self.storage_path = storage_path
        os.makedirs(storage_path, exist_ok=True)
    
    async def download(self, url: str) -> Optional[str]:
        try:
            async with httpx.AsyncClient(timeout=30.0) as client:
                response = await client.get(url)
                if response.status_code == 200:
                    content = response.content
                    ext = self._get_extension(url, content)
                    filename = self._generate_filename(ext)
                    filepath = os.path.join(self.storage_path, filename)
                    
                    with open(filepath, 'wb') as f:
                        f.write(content)
                    
                    return f"/uploads/images/{filename}"
        except Exception:
            return None
        
        return None
    
    def _get_extension(self, url: str, content: bytes) -> str:
        if url:
            path = url.split('?')[0]
            if '.' in path:
                ext = path.split('.')[-1].lower()
                if ext in ['jpg', 'jpeg', 'png', 'gif', 'webp']:
                    return ext
        
        if content[:4] == b'\xff\xd8\xff':
            return 'jpg'
        elif content[:4] == b'\x89PNG':
            return 'png'
        elif content[:6] in [b'GIF87a', b'GIF89a']:
            return 'gif'
        
        return 'jpg'
    
    def _generate_filename(self, ext: str) -> str:
        timestamp = datetime.now().strftime('%Y%m%d%H%M%S')
        random_str = hashlib.md5(str(datetime.now().timestamp()).encode()).hexdigest()[:8]
        return f"{timestamp}_{random_str}.{ext}"
    
    async def download_to_local(self, url: str, custom_filename: str = None) -> Optional[str]:
        try:
            async with httpx.AsyncClient(timeout=30.0) as client:
                response = await client.get(url)
                if response.status_code == 200:
                    content = response.content
                    ext = self._get_extension(url, content)
                    
                    if custom_filename:
                        filename = f"{custom_filename}.{ext}"
                    else:
                        filename = self._generate_filename(ext)
                    
                    filepath = os.path.join(self.storage_path, filename)
                    
                    with open(filepath, 'wb') as f:
                        f.write(content)
                    
                    return f"/uploads/images/{filename}"
        except Exception:
            return None
        
        return None
