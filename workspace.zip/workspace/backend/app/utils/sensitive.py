import re
from typing import List, Set


class SensitiveFilter:
    DEFAULT_WORDS: Set[str] = {
        "习近平", "国家领导人", "反动", "分裂", "赌博", "彩票",
        "毒品", "枪支", "色情", "裸聊", "援交", "代孕",
        "诈骗", "传销", "暴力", "恐怖", "血腥"
    }
    
    def __init__(self, custom_words: List[str] = None):
        self.words = self.DEFAULT_WORDS.copy()
        if custom_words:
            self.words.update(custom_words)
    
    def add_word(self, word: str):
        self.words.add(word)
    
    def add_words(self, words: List[str]):
        self.words.update(words)
    
    def filter(self, text: str) -> tuple:
        found = []
        
        for word in self.words:
            if word in text:
                found.append(word)
        
        return len(found) > 0, found
    
    def replace(self, text: str, replace_char: str = "*") -> str:
        result = text
        for word in self.words:
            result = result.replace(word, replace_char * len(word))
        return result
    
    def contains(self, text: str, word: str) -> bool:
        return word in text
