from sqlalchemy import Column, BigInteger, String, DateTime, Integer, SmallInteger
from sqlalchemy.sql import func
from app.core.database import Base


class Category(Base):
    __tablename__ = "categories"

    id = Column(BigInteger, primary_key=True, autoincrement=True)
    name = Column(String(50), nullable=False)
    sort = Column(Integer, default=0)
    status = Column(SmallInteger, default=1)
    create_time = Column(DateTime, server_default=func.now())
