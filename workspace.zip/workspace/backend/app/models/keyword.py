from sqlalchemy import Column, BigInteger, String, DateTime, Integer
from sqlalchemy.sql import func
from app.core.database import Base


class Keyword(Base):
    __tablename__ = "keywords"

    id = Column(BigInteger, primary_key=True, autoincrement=True)
    word = Column(String(100), nullable=False)
    category_id = Column(Integer, nullable=False)
    weight = Column(Integer, default=1)
    create_time = Column(DateTime, server_default=func.now())
