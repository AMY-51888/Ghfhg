from sqlalchemy import Column, BigInteger, String, Text, DateTime, Integer, SmallInteger
from sqlalchemy.sql import func
from app.core.database import Base


class Article(Base):
    __tablename__ = "articles"

    id = Column(BigInteger, primary_key=True, autoincrement=True)
    title = Column(String(500), nullable=False)
    content = Column(Text)
    cover = Column(String(1000))
    source_url = Column(String(1000), nullable=False)
    source_md5 = Column(String(32), nullable=False)
    category_id = Column(Integer, default=0)
    tags = Column(String(500))
    summary = Column(String(500))
    author = Column(String(200))
    publish_time = Column(DateTime)
    status = Column(SmallInteger, default=0)
    is_duplicate = Column(SmallInteger, default=0)
    sim_hash = Column(String(64))
    create_time = Column(DateTime, server_default=func.now())
    update_time = Column(DateTime, server_default=func.now(), onupdate=func.now())
