from sqlalchemy import Column, BigInteger, String, DateTime, Integer, Text, SmallInteger
from sqlalchemy.sql import func
from app.core.database import Base


class CrawlTask(Base):
    __tablename__ = "crawl_tasks"

    id = Column(BigInteger, primary_key=True, autoincrement=True)
    keyword = Column(String(100), nullable=False)
    source = Column(String(50), nullable=False)
    status = Column(String(20), default="idle")
    last_crawl_time = Column(DateTime)
    create_time = Column(DateTime, server_default=func.now())


class CrawlLog(Base):
    __tablename__ = "crawl_logs"

    id = Column(BigInteger, primary_key=True, autoincrement=True)
    task_id = Column(BigInteger, nullable=False)
    count = Column(Integer, default=0)
    duplicate_count = Column(Integer, default=0)
    status = Column(String(20))
    msg = Column(Text)
    create_time = Column(DateTime, server_default=func.now())
