from apscheduler.schedulers.asyncio import AsyncIOScheduler
from apscheduler.triggers.cron import CronTrigger
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, update
from app.core.database import AsyncSessionLocal
from app.core.redis import get_redis
from app.models.crawl import CrawlTask
from app.spiders.zhihu import ZhihuSpider
from app.spiders.xiaohongshu import XiaohongshuSpider
from app.spiders.bilibili import BilibiliSpider
from app.spiders.toutiao import ToutiaoSpider
from datetime import datetime


class CrawlScheduler:
    SPIDERS = {
        'zhihu': ZhihuSpider,
        'xiaohongshu': XiaohongshuSpider,
        'bilibili': BilibiliSpider,
        'toutiao': ToutiaoSpider
    }
    
    def __init__(self):
        self.scheduler = AsyncIOScheduler()
    
    def start(self):
        self.scheduler.add_job(
            self.run_crawl_tasks,
            CronTrigger(hour=8, minute=0),
            id='crawl_morning',
            replace_existing=True
        )
        self.scheduler.add_job(
            self.run_crawl_tasks,
            CronTrigger(hour=14, minute=0),
            id='crawl_afternoon',
            replace_existing=True
        )
        self.scheduler.add_job(
            self.run_crawl_tasks,
            CronTrigger(hour=20, minute=0),
            id='crawl_evening',
            replace_existing=True
        )
        
        self.scheduler.start()
    
    def stop(self):
        self.scheduler.shutdown()
    
    async def run_crawl_tasks(self):
        async with AsyncSessionLocal() as db:
            redis_client = get_redis()
            
            result = await db.execute(select(CrawlTask))
            tasks = result.scalars().all()
            
            for task in tasks:
                lock_key = f"crawl_task:{task.id}:running"
                is_running = await redis_client.get(lock_key)
                
                if is_running:
                    continue
                
                await self.run_single_task(db, task)
            
            await db.commit()
    
    async def run_single_task(self, db: AsyncSession, task: CrawlTask):
        spider_class = self.SPIDERS.get(task.source)
        if not spider_class:
            return
        
        spider = spider_class()
        
        try:
            await db.execute(
                update(CrawlTask)
                .where(CrawlTask.id == task.id)
                .values(status='running', last_crawl_time=datetime.now())
            )
            await db.commit()
            
            items = await spider.crawl(task.keyword)
            
            for item in items:
                normalized = spider.normalize(item)
            
            await db.execute(
                update(CrawlTask)
                .where(CrawlTask.id == task.id)
                .values(status='idle')
            )
            await db.commit()
            
        except Exception as e:
            await db.execute(
                update(CrawlTask)
                .where(CrawlTask.id == task.id)
                .values(status='idle')
            )
            await db.commit()
        
        finally:
            await spider.close()
