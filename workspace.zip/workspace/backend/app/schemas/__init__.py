from pydantic import BaseModel, Field
from typing import Optional, List
from datetime import datetime


class ArticleBase(BaseModel):
    title: str
    content: Optional[str] = None
    cover: Optional[str] = None
    source_url: str
    category_id: int = 0
    tags: Optional[str] = None
    summary: Optional[str] = None
    author: Optional[str] = None
    publish_time: Optional[datetime] = None


class ArticleCreate(ArticleBase):
    pass


class ArticleUpdate(BaseModel):
    title: Optional[str] = None
    content: Optional[str] = None
    cover: Optional[str] = None
    category_id: Optional[int] = None
    tags: Optional[str] = None
    summary: Optional[str] = None
    status: Optional[int] = None


class ArticleResponse(ArticleBase):
    id: int
    source_md5: str
    status: int
    is_duplicate: int
    sim_hash: Optional[str] = None
    create_time: datetime
    update_time: datetime

    class Config:
        from_attributes = True


class ArticleListResponse(BaseModel):
    id: int
    title: str
    cover: Optional[str] = None
    category_id: int
    summary: Optional[str] = None
    author: Optional[str] = None
    publish_time: Optional[datetime] = None
    create_time: datetime

    class Config:
        from_attributes = True


class CategoryBase(BaseModel):
    name: str
    sort: int = 0
    status: int = 1


class CategoryCreate(CategoryBase):
    pass


class CategoryResponse(CategoryBase):
    id: int

    class Config:
        from_attributes = True


class CrawlTaskBase(BaseModel):
    keyword: str
    source: str


class CrawlTaskCreate(CrawlTaskBase):
    pass


class CrawlTaskResponse(CrawlTaskBase):
    id: int
    status: str
    last_crawl_time: Optional[datetime] = None
    create_time: datetime

    class Config:
        from_attributes = True


class CrawlLogResponse(BaseModel):
    id: int
    task_id: int
    count: int
    duplicate_count: int
    status: str
    msg: Optional[str] = None
    create_time: datetime

    class Config:
        from_attributes = True


class KeywordBase(BaseModel):
    word: str
    category_id: int
    weight: int = 1


class KeywordCreate(KeywordBase):
    pass


class KeywordResponse(KeywordBase):
    id: int

    class Config:
        from_attributes = True


class LoginRequest(BaseModel):
    username: str
    password: str


class LoginResponse(BaseModel):
    token: str
    expires_in: int


class PageResponse(BaseModel):
    items: List
    total: int
    page: int
    page_size: int


class HomeResponse(BaseModel):
    latest_articles: List
    hot_articles: List
    categories: List


class CrawlCallbackRequest(BaseModel):
    task_id: int
    articles: List[ArticleCreate]
    duplicate_count: int = 0
    status: str = "success"
    msg: Optional[str] = None


class BatchRequest(BaseModel):
    action: str
    ids: List[int]
    category_id: Optional[int] = None


class DuplicateHandleRequest(BaseModel):
    id: int
    action: str


class SettingsUpdateRequest(BaseModel):
    site_name: Optional[str] = None
    site_url: Optional[str] = None
    seo_title: Optional[str] = None
    seo_keywords: Optional[str] = None
    seo_description: Optional[str] = None
    site_logo: Optional[str] = None
