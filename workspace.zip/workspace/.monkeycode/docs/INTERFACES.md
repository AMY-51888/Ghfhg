# 接口定义

## 基础信息

- 基础URL: `/api`
- 管理后台URL: `/admin`
- 数据格式: JSON
- 认证方式: JWT Bearer Token

## 公共接口

### 文章列表

```
GET /api/articles/list
```

**Query Parameters:**
| 参数 | 类型 | 必填 | 说明 |
|------|------|------|------|
| page | int | 否 | 页码，默认1 |
| page_size | int | 否 | 每页条数，默认20 |
| category_id | int | 否 | 分类ID |
| status | int | 否 | 状态：0待审核 1已发布 |
| sort | string | 否 | 排序：create_time/publish_time |

**响应示例:**
```json
{
  "code": 0,
  "message": "success",
  "data": {
    "items": [
      {
        "id": 1,
        "title": "TikTok运营入门教程",
        "cover": "https://example.com/cover.jpg",
        "category_id": 1,
        "category_name": "运营教程",
        "summary": "本文介绍TikTok运营的基础知识...",
        "author": "张三",
        "publish_time": "2024-01-15 10:30:00",
        "create_time": "2024-01-15 12:00:00"
      }
    ],
    "total": 100,
    "page": 1,
    "page_size": 20
  }
}
```

### 文章详情

```
GET /api/articles/detail/{id}
```

**路径参数:**
- id: 文章ID

**响应示例:**
```json
{
  "code": 0,
  "message": "success",
  "data": {
    "id": 1,
    "title": "TikTok运营入门教程",
    "content": "<p>正文内容...</p>",
    "cover": "https://example.com/cover.jpg",
    "source_url": "https://zhihu.com/p/123",
    "category_id": 1,
    "category_name": "运营教程",
    "tags": "TikTok,运营,教程",
    "summary": "本文介绍TikTok运营的基础知识...",
    "author": "张三",
    "publish_time": "2024-01-15 10:30:00",
    "create_time": "2024-01-15 12:00:00"
  }
}
```

### 分类文章列表

```
GET /api/articles/category/{id}
```

**路径参数:**
- id: 分类ID

**Query Parameters:** 同文章列表

### 文章搜索

```
GET /api/articles/search
```

**Query Parameters:**
| 参数 | 类型 | 必填 | 说明 |
|------|------|------|------|
| q | string | 是 | 搜索关键词 |
| page | int | 否 | 页码 |
| page_size | int | 否 | 每页条数 |

**响应示例:**
```json
{
  "code": 0,
  "message": "success",
  "data": {
    "items": [...],
    "total": 50,
    "page": 1,
    "page_size": 20
  }
}
```

### 首页数据

```
GET /api/home
```

**响应示例:**
```json
{
  "code": 0,
  "message": "success",
  "data": {
    "latest_articles": [...],
    "hot_articles": [...],
    "categories": [
      {"id": 1, "name": "运营教程", "count": 100},
      {"id": 2, "name": "小店电商", "count": 80},
      ...
    ]
  }
}
```

### 全部分类

```
GET /api/categories
```

**响应示例:**
```json
{
  "code": 0,
  "message": "success",
  "data": [
    {"id": 1, "name": "运营教程", "sort": 1},
    {"id": 2, "name": "小店电商", "sort": 2},
    {"id": 3, "name": "广告投放", "sort": 3},
    {"id": 4, "name": "工具资源", "sort": 4},
    {"id": 5, "name": "最新资讯", "sort": 5},
    {"id": 6, "name": "模板脚本", "sort": 6}
  ]
}
```

## 管理后台接口

### 管理员登录

```
POST /admin/login
```

**请求体:**
```json
{
  "username": "admin",
  "password": "password"
}
```

**响应示例:**
```json
{
  "code": 0,
  "message": "success",
  "data": {
    "token": "eyJhbGciOiJIUzI1NiIs...",
    "expires_in": 86400
  }
}
```

### 文章管理

#### 文章列表

```
GET /admin/articles
```

**Query Parameters:**
| 参数 | 类型 | 必填 | 说明 |
|------|------|------|------|
| page | int | 否 | 页码 |
| page_size | int | 否 | 每页条数 |
| category_id | int | 否 | 分类ID |
| status | int | 否 | 状态 |
| is_duplicate | int | 否 | 是否重复 |
| keyword | string | 否 | 搜索关键词 |

#### 编辑文章

```
POST /admin/article/edit
```

**请求体:**
```json
{
  "id": 1,
  "title": "修改后的标题",
  "content": "修改后的内容",
  "category_id": 2,
  "tags": "TikTok,运营",
  "status": 1
}
```

#### 删除文章

```
POST /admin/article/delete
```

**请求体:**
```json
{
  "id": 1
}
```

#### 批量操作

```
POST /admin/article/batch
```

**请求体:**
```json
{
  "action": "delete|publish|category",
  "ids": [1, 2, 3],
  "category_id": 1
}
```

### 采集任务管理

#### 任务列表

```
GET /admin/crawl/tasks
```

**响应示例:**
```json
{
  "code": 0,
  "message": "success",
  "data": [
    {
      "id": 1,
      "keyword": "TikTok运营",
      "source": "zhihu",
      "status": "running",
      "last_crawl_time": "2024-01-15 14:00:00"
    }
  ]
}
```

#### 启动任务

```
POST /admin/crawl/start
```

**请求体:**
```json
{
  "task_id": 1
}
```

或启动全部:
```json
{
  "all": true
}
```

#### 停止任务

```
POST /admin/crawl/stop
```

**请求体:**
```json
{
  "task_id": 1
}
```

#### 任务日志

```
GET /admin/crawl/logs
```

**Query Parameters:**
| 参数 | 类型 | 必填 | 说明 |
|------|------|------|------|
| task_id | int | 否 | 任务ID |
| page | int | 否 | 页码 |
| page_size | int | 否 | 每页条数 |

### 去重管理

#### 重复内容列表

```
GET /admin/duplicate/list
```

**Query Parameters:**
| 参数 | 类型 | 必填 | 说明 |
|------|------|------|------|
| page | int | 否 | 页码 |
| page_size | int | 否 | 每页条数 |

**响应示例:**
```json
{
  "code": 0,
  "message": "success",
  "data": {
    "items": [
      {
        "id": 1,
        "title": "TikTok运营教程",
        "sim_hash": "abc123...",
        "duplicate_with": {
          "id": 2,
          "title": "TikTok运营教程（续）"
        },
        "create_time": "2024-01-15 12:00:00"
      }
    ],
    "total": 50,
    "page": 1
  }
}
```

#### 处理重复

```
POST /admin/duplicate/handle
```

**请求体:**
```json
{
  "id": 1,
  "action": "keep|delete|ignore"
}
```

### 分类管理

#### 分类列表

```
GET /admin/categories
```

#### 创建/编辑分类

```
POST /admin/category/edit
```

**请求体:**
```json
{
  "id": 1,
  "name": "新分类",
  "sort": 1,
  "status": 1
}
```

### 关键词管理

#### 关键词列表

```
GET /admin/keywords
```

**Query Parameters:**
| 参数 | 类型 | 必填 | 说明 |
|------|------|------|------|
| category_id | int | 否 | 分类ID |

#### 编辑关键词

```
POST /admin/keyword/edit
```

**请求体:**
```json
{
  "id": 1,
  "word": "TikTok",
  "category_id": 1,
  "weight": 1
}
```

### 网站设置

#### 获取设置

```
GET /admin/settings
```

**响应示例:**
```json
{
  "code": 0,
  "message": "success",
  "data": {
    "site_name": "TikTok资源资讯聚合",
    "site_url": "https://example.com",
    "seo_title": "TikTok资源资讯聚合平台",
    "seo_keywords": "TikTok,跨境电商,运营教程",
    "seo_description": "专业的TikTok资源资讯聚合平台",
    "site_logo": "/uploads/logo.png"
  }
}
```

#### 更新设置

```
POST /admin/settings/update
```

**请求体:**
```json
{
  "site_name": "TikTok资源资讯聚合",
  "seo_keywords": "TikTok,跨境电商"
}
```

## 采集回调接口

### 爬取完成回调

```
POST /api/callback/crawl_finish
```

**请求体:**
```json
{
  "task_id": 1,
  "articles": [
    {
      "title": "文章标题",
      "content": "文章内容",
      "cover": "封面图URL",
      "source_url": "来源URL",
      "author": "作者",
      "publish_time": "2024-01-15 10:30:00"
    }
  ],
  "duplicate_count": 5,
  "status": "success",
  "msg": ""
}
```

## 错误码定义

| 错误码 | 说明 |
|--------|------|
| 0 | 成功 |
| 1001 | 参数错误 |
| 1002 | 资源不存在 |
| 2001 | 未授权 |
| 2002 | 登录失败 |
| 2003 | 权限不足 |
| 3001 | 服务器内部错误 |
