# 开发指南

## 环境要求

### 后端环境

- Python 3.10+
- MySQL 8.0
- Redis 6.0+
- Docker (可选)

### 前端环境

- Node.js 18+
- pnpm 8+

## 快速开始

### 1. 克隆代码

```bash
git clone <repository_url>
cd tiktok-news-aggregator
```

### 2. 后端快速启动

```bash
cd backend

# 创建虚拟环境
python -m venv venv
source venv/bin/activate  # Linux/Mac
venv\Scripts\activate     # Windows

# 安装依赖
pip install -r requirements.txt

# 配置环境变量
cp .env.example .env
# 编辑 .env 配置数据库和Redis连接

# 初始化数据库
mysql -u root -p < ../scripts/init_db.sql

# 启动服务
uvicorn main:app --reload --host 0.0.0.0 --port 8000
```

### 3. 前端快速启动

```bash
cd frontend

# 安装依赖
pnpm install

# 启动开发服务器
pnpm dev
```

### 4. Docker 部署

```bash
cd docker

# 启动全部服务
docker-compose up -d

# 查看日志
docker-compose logs -f
```

## 项目结构说明

### 后端目录结构

```
backend/
├── app/
│   ├── api/              # API路由层
│   │   ├── articles.py   # 文章相关接口
│   │   ├── categories.py # 分类相关接口
│   │   ├── home.py       # 首页接口
│   │   ├── admin/        # 管理后台接口
│   │   │   ├── login.py  # 登录接口
│   │   │   ├── article.py # 文章管理
│   │   │   ├── crawl.py  # 采集管理
│   │   │   └── settings.py # 系统设置
│   │   └── callback/     # 回调接口
│   │       └── crawl.py  # 爬虫回调
│   ├── core/             # 核心配置
│   │   ├── config.py     # 应用配置
│   │   ├── database.py   # 数据库连接
│   │   ├── redis.py      # Redis连接
│   │   └── security.py   # 安全认证
│   ├── models/           # 数据模型
│   │   ├── article.py    # 文章模型
│   │   ├── category.py   # 分类模型
│   │   ├── crawl.py      # 采集模型
│   │   └── keyword.py    # 关键词模型
│   ├── schemas/          # Pydantic模型
│   │   ├── article.py
│   │   ├── request.py
│   │   └── response.py
│   ├── services/         # 业务逻辑层
│   │   ├── article_service.py
│   │   ├── dedup_service.py  # 去重服务
│   │   ├── classify_service.py # 分类服务
│   │   ├── content_processor.py # 内容处理
│   │   └── crawl_service.py  # 采集服务
│   ├── spiders/          # 爬虫模块
│   │   ├── __init__.py
│   │   ├── base.py       # 基类
│   │   ├── zhihu.py
│   │   ├── xiaohongshu.py
│   │   ├── bilibili.py
│   │   └── toutiao.py
│   ├── tasks/            # 定时任务
│   │   └── scheduler.py
│   └── utils/            # 工具函数
│       ├── simhash.py
│       ├── text_similar.py
│       ├── sensitive.py  # 敏感词过滤
│       └── image.py      # 图片处理
├── main.py               # 应用入口
└── requirements.txt
```

### 前端目录结构

```
frontend/
├── src/
│   ├── api/              # API调用模块
│   │   ├── request.js    # axios封装
│   │   ├── articles.js   # 文章API
│   │   ├── admin.js      # 管理API
│   │   └── crawl.js      # 采集API
│   ├── components/       # 公共组件
│   │   ├── ArticleCard.vue
│   │   ├── CategoryNav.vue
│   │   └── Pagination.vue
│   ├── views/            # 页面视图
│   │   ├── home/        # 前台页面
│   │   │   ├── Index.vue  # 首页
│   │   │   ├── List.vue   # 分类列表
│   │   │   ├── Detail.vue # 文章详情
│   │   │   └── Search.vue # 搜索结果
│   │   └── admin/       # 后台页面
│   │       ├── Login.vue
│   │       ├── Dashboard.vue
│   │       ├── ArticleList.vue
│   │       ├── CrawlManage.vue
│   │       ├── DuplicateList.vue
│   │       ├── CategoryManage.vue
│   │       ├── KeywordManage.vue
│   │       └── Settings.vue
│   ├── router/          # 路由配置
│   │   └── index.js
│   ├── stores/          # 状态管理
│   │   ├── user.js
│   │   └── settings.js
│   ├── styles/          # 全局样式
│   │   └── main.css
│   ├── App.vue
│   └── main.js
├── index.html
├── package.json
└── vite.config.js
```

## 开发规范

### 后端规范

#### 1. 代码风格

- 遵循 PEP 8
- 使用 Black 格式化代码
- 使用 Pydantic 进行数据验证

#### 2. API设计原则

- RESTful API 规范
- 统一响应格式
- 适当的HTTP状态码

#### 3. 数据库规范

- 表名使用单数下划线命名
- 字段使用小写下划线命名
- 必须设置索引
- 软删除优先

#### 4. 异常处理

```python
from fastapi import HTTPException

raise HTTPException(status_code=400, detail="错误信息")
```

### 前端规范

#### 1. 代码风格

- 遵循 Vue 3  Composition API
- 使用 ESLint + Prettier
- 组件名使用 PascalCase

#### 2. 目录规范

- 公共组件放在 components/
- 页面组件放在 views/
- 复用逻辑使用 composables/

#### 3. 命名规范

- 组件文件: PascalCase.vue
- 工具函数: camelCase.js
- 常量: UPPER_SNAKE_CASE

## 数据库初始化

### 执行SQL脚本

```bash
mysql -u root -p < scripts/init_db.sql
```

### 初始化关键词数据

```sql
-- 运营教程
INSERT INTO keywords (word, category_id, weight) VALUES
('起号', 1, 1), ('流量', 1, 1), ('剪辑', 1, 1), ('文案', 1, 1),
('TikTok运营', 1, 2), ('账号运营', 1, 2);

-- 小店电商
INSERT INTO keywords (word, category_id, weight) VALUES
('小店', 2, 1), ('佣金', 2, 1), ('选品', 2, 1), ('物流', 2, 1),
('定价', 2, 1), ('TikTok小店', 2, 2), ('跨境电商', 2, 2);

-- 广告投放
INSERT INTO keywords (word, category_id, weight) VALUES
('ROI', 3, 1), ('广告', 3, 1), ('投放', 3, 1), ('BC', 3, 1),
('消耗', 3, 1), ('广告投放', 3, 2);

-- 工具资源
INSERT INTO keywords (word, category_id, weight) VALUES
('工具', 4, 1), ('去水印', 4, 1), ('解析', 4, 1), ('批量', 4, 1),
('下载', 4, 1);

-- 最新资讯
INSERT INTO keywords (word, category_id, weight) VALUES
('新规', 5, 1), ('政策', 5, 1), ('更新', 5, 1), ('公告', 5, 1),
('TikTok公告', 5, 2);

-- 模板脚本
INSERT INTO keywords (word, category_id, weight) VALUES
('话术', 6, 1), ('脚本', 6, 1), ('模板', 6, 1), ('资料', 6, 1);
```

## 常见任务

### 添加新爬虫

1. 在 `spiders/` 目录创建新文件，如 `douyin.py`
2. 继承 `BaseSpider` 类
3. 实现 `parse()` 方法
4. 在 `spiders/__init__.py` 中注册

```python
from .base import BaseSpider

class DouyinSpider(BaseSpider):
    name = 'douyin'
    source = 'douyin'
    
    def parse(self, response):
        # 解析页面内容
        items = []
        for item in response.css('.item'):
            items.append({
                'title': item.css('title::text').get(),
                'content': item.css('content::text').get(),
                'author': item.css('author::text').get(),
            })
        return items
```

### 添加新分类

1. 在数据库插入分类
2. 在 `categories` 表添加记录
3. 在分类服务中添加对应关键词

### 配置敏感词

编辑 `utils/sensitive.py` 中的敏感词列表，或从数据库读取。

## 环境变量说明

### 后端 .env

```env
# 数据库配置
DATABASE_URL=mysql+aiomysql://user:pass@localhost:3306/tiktok_news

# Redis配置
REDIS_URL=redis://localhost:6379/0

# JWT密钥
SECRET_KEY=your-secret-key-change-in-production
ALGORITHM=HS256

# 管理员账号
ADMIN_USERNAME=admin
ADMIN_PASSWORD=admin123

# 图片存储
IMAGE_STORAGE=local  # local 或 oss
OSS_BUCKET=your-bucket
OSS_ENDPOINT=oss-cn-hangzhou.aliyuncs.com
```

## 构建与发布

### 后端构建

```bash
cd backend
docker build -f docker/backend.Dockerfile -t tiktok-backend .
```

### 前端构建

```bash
cd frontend
pnpm build
```

### 完整部署

```bash
cd docker
docker-compose up -d
```
