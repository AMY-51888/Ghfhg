# 架构设计

## 系统概述

TikTok资源资讯聚合平台采用前后端分离架构，后端负责数据采集、处理、存储和API服务，前端负责内容展示和管理后台。

## 技术栈

| 类别 | 技术 | 说明 |
|------|------|------|
| 后端 | Python 3.10+ | 核心语言环境 |
| Web框架 | FastAPI | 高性能异步API框架 |
| 爬虫 | Scrapy + Splash | 分布式爬虫 + JS渲染 |
| 数据库 | MySQL 8.0 | 主数据存储 |
| 缓存 | Redis 6.0 | 去重缓存、任务队列 |
| 前端 | Vue3 + Element Plus | SPA管理后台 |
| 部署 | Docker | 容器化部署 |

## 项目结构

```
tiktok-news-aggregator/
├── backend/                    # Python后端
│   ├── app/
│   │   ├── api/              # API路由
│   │   │   ├── articles.py   # 文章接口
│   │   │   ├── admin/        # 管理后台接口
│   │   │   └── crawl/        # 采集回调接口
│   │   ├── core/             # 核心模块
│   │   │   ├── config.py     # 配置管理
│   │   │   ├── database.py   # 数据库连接
│   │   │   └── security.py   # 安全认证
│   │   ├── models/           # 数据模型
│   │   │   ├── article.py
│   │   │   ├── category.py
│   │   │   └── crawl.py
│   │   ├── services/         # 业务逻辑
│   │   │   ├── article_service.py
│   │   │   ├── dedup_service.py  # 去重服务
│   │   │   ├── classify_service.py # 分类服务
│   │   │   └── content_processor.py # 内容处理
│   │   ├── spiders/          # 爬虫模块
│   │   │   ├── base_spider.py
│   │   │   ├── zhihu.py
│   │   │   ├── xiaohongshu.py
│   │   │   ├── bilibili.py
│   │   │   └── toutiao.py
│   │   ├── tasks/            # 定时任务
│   │   │   └── crawl_scheduler.py
│   │   └── utils/            # 工具函数
│   │       ├── simhash.py    # SimHash实现
│   │       ├── text_similar.py # 文本相似度
│   │       └── image_handler.py # 图片处理
│   ├── requirements.txt
│   └── main.py               # 应用入口
├── frontend/                  # Vue3前端
│   ├── src/
│   │   ├── api/              # API调用
│   │   ├── components/       # 公共组件
│   │   ├── views/            # 页面视图
│   │   │   ├── home/         # 前台页面
│   │   │   └── admin/         # 后台页面
│   │   ├── router/           # 路由配置
│   │   ├── stores/           # 状态管理
│   │   └── styles/           # 全局样式
│   ├── package.json
│   └── vite.config.js
├── docker/                    # Docker配置
│   ├── docker-compose.yml
│   ├── backend.Dockerfile
│   └── frontend.Dockerfile
└── scripts/                   # 运维脚本
    ├── init_db.sql
    └── crawl_once.sh
```

## 核心模块

### 1. 爬虫模块 (spiders/)

负责从各平台采集内容，采用策略模式设计。

**基类 BaseSpider:**
- 统一入口 `crawl(keyword)`
- 内容解析 `parse(response)`
- 字段标准化 `normalize(item)`

**数据采集流程:**
```mermaid
graph TD
    A[定时触发/手动启动] --> B[从关键词池取关键词]
    B --> C[构建搜索URL]
    C --> D[Scrapy发起请求]
    D --> E{是否需要JS渲染}
    E -->|是| F[Splash渲染]
    E -->|否| G[直接解析]
    F --> H[提取内容字段]
    G --> H
    H --> I[内容清洗]
    I --> J[去重检查]
    J --> K{是否重复}
    K -->|是| L[记录日志丢弃]
    K -->|否| M[自动分类]
    M --> N[存入数据库]
```

### 2. 去重服务 (services/dedup_service.py)

三重去重机制保障内容唯一性。

**URL MD5去重:**
- 入库前检查 source_url 的 MD5 是否已存在
- 使用 Redis SET 存储已处理URL，O(1)查询

**标题相似度去重:**
- 使用余弦相似度计算标题相似度
- 阈值: >85% 判定为重复

**正文SimHash去重:**
- 对正文提取SimHash指纹
- 存储到MySQL，使用汉明距离 < 5 判定重复
- 可选: Redis布隆过滤器加速预检

```mermaid
graph LR
    A[新内容] --> B[URL MD5检查]
    B --> C{已存在?}
    C -->|是| D[丢弃]
    C -->|否| E[标题相似度检查]
    E --> F{相似度>85%?}
    F -->|是| D
    F -->|否| G[SimHash检查]
    G --> H{汉明距离<5?}
    H -->|是| D
    H -->|否| I[入库]
```

### 3. 分类服务 (services/classify_service.py)

基于关键词规则匹配的自动分类系统。

**分类规则表:**
| 分类 | 关键词 | 权重 |
|------|--------|------|
| 运营教程 | 起号、流量、剪辑、文案 | 1 |
| 小店电商 | 小店、佣金、选品、物流、定价 | 1 |
| 广告投放 | ROI、广告、投放、BC、消耗 | 1 |
| 工具资源 | 工具、去水印、解析、批量 | 1 |
| 最新资讯 | 新规、政策、更新、公告 | 1 |
| 模板脚本 | 话术、脚本、模板、资料 | 1 |

**分类流程:**
- 合并标题+正文转换为小写
- 遍历关键词规则表，匹配计算权重
- 权重最高分类为结果，未匹配为"未分类"

### 4. 内容处理引擎 (services/content_processor.py)

自动化内容清洗和增强。

**处理步骤:**
1. 去除外链、二维码、公众号信息
2. 提取正文摘要（前120字）
3. 自动生成TAG标签
4. 图片下载到本地/OSS
5. 敏感词过滤（基于词库匹配）
6. 格式化排版（段落、换行）

### 5. 定时任务 (tasks/crawl_scheduler.py)

使用 APScheduler 实现定时采集。

**执行策略:**
- 每天 3 次: 8:00、14:00、20:00
- 每个关键词池轮询执行
- 使用 Redis 分布式锁防止重复执行

## 数据库设计

### articles 文章表

```sql
CREATE TABLE articles (
    id BIGINT PRIMARY KEY AUTO_INCREMENT,
    title VARCHAR(500) NOT NULL COMMENT '标题',
    content MEDIUMTEXT COMMENT '正文',
    cover VARCHAR(1000) COMMENT '封面图',
    source_url VARCHAR(1000) NOT NULL COMMENT '来源链接',
    source_md5 VARCHAR(32) NOT NULL COMMENT 'URL MD5去重',
    category_id INT DEFAULT 0 COMMENT '分类ID',
    tags VARCHAR(500) COMMENT '标签',
    summary VARCHAR(500) COMMENT '摘要',
    author VARCHAR(200) COMMENT '作者',
    publish_time DATETIME COMMENT '发布时间',
    status TINYINT DEFAULT 0 COMMENT '0待审核 1已发布 2垃圾内容',
    is_duplicate TINYINT DEFAULT 0 COMMENT '是否重复',
    sim_hash VARCHAR(64) COMMENT 'SimHash指纹',
    create_time DATETIME DEFAULT CURRENT_TIMESTAMP,
    update_time DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_source_md5 (source_md5),
    INDEX idx_sim_hash (sim_hash(10)),
    INDEX idx_category (category_id),
    INDEX idx_status (status),
    INDEX idx_create_time (create_time)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
```

### categories 分类表

```sql
CREATE TABLE categories (
    id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(50) NOT NULL COMMENT '分类名',
    sort INT DEFAULT 0 COMMENT '排序',
    status TINYINT DEFAULT 1 COMMENT '状态',
    create_time DATETIME DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO categories (id, name, sort) VALUES
(1, '运营教程', 1),
(2, '小店电商', 2),
(3, '广告投放', 3),
(4, '工具资源', 4),
(5, '最新资讯', 5),
(6, '模板脚本', 6),
(0, '未分类', 0);
```

### crawl_tasks 采集任务表

```sql
CREATE TABLE crawl_tasks (
    id INT PRIMARY KEY AUTO_INCREMENT,
    keyword VARCHAR(100) NOT NULL COMMENT '关键词',
    source VARCHAR(50) NOT NULL COMMENT '来源平台',
    status VARCHAR(20) DEFAULT 'idle' COMMENT '运行状态',
    last_crawl_time DATETIME COMMENT '最后爬取时间',
    create_time DATETIME DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
```

### crawl_logs 爬取日志表

```sql
CREATE TABLE crawl_logs (
    id INT PRIMARY KEY AUTO_INCREMENT,
    task_id INT NOT NULL COMMENT '任务ID',
    count INT DEFAULT 0 COMMENT '抓取条数',
    duplicate_count INT DEFAULT 0 COMMENT '重复条数',
    status VARCHAR(20) COMMENT '状态',
    msg TEXT COMMENT '日志信息',
    create_time DATETIME DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
```

### keywords 关键词规则表

```sql
CREATE TABLE keywords (
    id INT PRIMARY KEY AUTO_INCREMENT,
    word VARCHAR(100) NOT NULL COMMENT '关键词',
    category_id INT NOT NULL COMMENT '对应分类',
    weight INT DEFAULT 1 COMMENT '权重',
    create_time DATETIME DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_category (category_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
```

## 部署架构

```mermaid
graph TD
    subgraph Docker Compose
        A[Nginx 80/443] --> B[Vue3 Frontend 3000]
        A --> C[FastAPI Backend 8000]
        C --> D[(MySQL 3306)]
        C --> E[(Redis 6379)]
    end
    
    F[定时任务] --> C
    C --> G[Scrapy Crawler]
    G --> H[外部网站]
```

**容器规划:**
- `nginx`: 反向代理 + HTTPS
- `backend`: FastAPI 应用服务
- `frontend`: Vue3 构建的静态文件
- `mysql`: 数据库服务
- `redis`: 缓存和队列
