# TikTok资源资讯聚合平台 实施计划

- [x] 1. 项目基础架构搭建
  - [x] 1.1 创建后端项目结构和目录
  - [x] 1.2 创建前端项目结构（使用 Vite + Vue3）
  - [x] 1.3 编写后端 requirements.txt 依赖文件
  - [x] 1.4 编写前端 package.json 依赖文件
  - [ ] 1.5 创建 Docker 配置文件（docker-compose.yml, Dockerfile）
  - [ ] 1.6 创建数据库初始化脚本 scripts/init_db.sql

- [x] 2. 后端核心模块实现
  - [x] 2.1 实现 core/config.py 配置管理
  - [x] 2.2 实现 core/database.py 数据库连接（SQLAlchemy + aiomysql）
  - [x] 2.3 实现 core/redis.py Redis 连接
  - [x] 2.4 实现 core/security.py JWT 认证

- [x] 3. 数据模型层实现
  - [x] 3.1 实现 models/article.py 文章模型
  - [x] 3.2 实现 models/category.py 分类模型
  - [x] 3.3 实现 models/crawl.py 采集任务和日志模型
  - [x] 3.4 实现 models/keyword.py 关键词模型
  - [x] 3.5 创建 Pydantic schemas 数据验证模型

- [x] 4. 工具模块实现
  - [x] 4.1 实现 utils/simhash.py SimHash 算法（用于正文去重）
  - [x] 4.2 实现 utils/text_similar.py 标题相似度计算（余弦相似度）
  - [x] 4.3 实现 utils/sensitive.py 敏感词过滤
  - [x] 4.4 实现 utils/image.py 图片下载和处理

- [x] 5. 核心业务服务实现
  - [x] 5.1 实现 services/dedup_service.py 三重去重服务
  - [x] 5.2 实现 services/classify_service.py 自动分类服务
  - [x] 5.3 实现 services/content_processor.py 内容处理引擎
  - [x] 5.4 实现 services/article_service.py 文章CRUD服务

- [x] 6. 爬虫模块实现
  - [x] 6.1 实现 spiders/base.py 爬虫基类
  - [x] 6.2 实现 spiders/zhihu.py 知乎爬虫
  - [x] 6.3 实现 spiders/xiaohongshu.py 小红书爬虫
  - [x] 6.4 实现 spiders/bilibili.py B站爬虫
  - [x] 6.5 实现 spiders/toutiao.py 今日头条爬虫

- [x] 7. 定时任务模块
  - [x] 7.1 实现 tasks/crawl_scheduler.py APScheduler 定时任务
  - [x] 7.2 配置每天3次定时爬取（8:00、14:00、20:00）

- [x] 8. API 接口实现
  - [x] 8.1 实现 api/articles.py 文章列表/详情/搜索接口
  - [x] 8.2 实现 api/categories.py 分类接口
  - [x] 8.3 实现 api/home.py 首页接口
  - [x] 8.4 实现 api/callback/crawl.py 爬虫回调接口
  - [x] 8.5 实现管理后台 API（admin/login.py, admin/article.py, admin/crawl.py 等）

- [x] 9. 前端实现
  - [x] 9.1 配置 Vue3 + Vite + Element Plus 项目
  - [x] 9.2 实现 api/request.js axios 封装
  - [x] 9.3 实现前台页面 views/home/（首页、列表、详情、搜索）
  - [x] 9.4 实现管理后台 views/admin/（Dashboard、文章管理、采集管理、去重管理）
  - [x] 9.5 配置前端路由和状态管理

- [ ] 10. 检查点 - 确保核心功能可用
  - 确保所有测试通过，如有疑问请询问用户

- [ ] 11. 部署配置
  - [ ] 11.1 配置 Nginx 反向代理
  - [ ] 11.2 配置 Docker 多容器部署
  - [ ] 11.3 编写部署文档
